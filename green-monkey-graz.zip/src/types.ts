export type ProductCategory = 
  | 'all' 
  | 'raw'
  | 'filters' 
  | 'headshop' 
  | 'grinder' 
  | 'smartshop'
  | 'cbd'
  | 'tea';

export type StoreId = 'annen' | 'jako';

export type AppView = 'home' | 'catalog';

export type BrandName = 
  | 'RAW'
  | 'OCB'
  | 'Cannaline'
  | 'Champ High'
  | 'Jelly Joker'
  | "Granny's"
  | 'Best Buds'
  | 'Purize'
  | 'ActiTube'
  | 'Marie'
  | 'G-Rollz'
  | 'Clipper'
  | 'Hemper'
  | 'Green Monkey';

export interface Product {
  id: string;
  title: string;
  brand: BrandName | string;
  category: ProductCategory;
  categoryLabel: string;
  brief: string;
  priceEstimate?: string;
  badge?: string;
  badgeType?: 'gold' | 'green' | 'default' | 'raw' | 'champhigh';
  icon: string;
  imageUrl?: string;
  mediaGradient: string;
  specs: string[];
  stockLocation: 'both' | 'annen' | 'jako';
  stockNote: string;
}

export interface StoreLocation {
  id: StoreId;
  name: string;
  shortName: string;
  tagline: string;
  address: string;
  postalCode: string;
  city: string;
  stationCode: string;
  hoursWeekday: string;
  hoursWeekend: string;
  phone: string;
  phoneDisplay: string;
  email: string;
  tramInfo: string;
  mapsUrl: string;
  embedUrl: string;
  featured?: boolean;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}
