import React, { useState } from 'react';
import { Product, ProductCategory } from '../types';
import { PRODUCTS } from '../data/storeData';
import { CatalogItemModal } from './CatalogItemModal';
import { 
  Search, 
  Sparkles, 
  MapPin, 
  Store, 
  Info, 
  ArrowLeft, 
  Flame, 
  Layers, 
  FlaskConical, 
  Cog, 
  ShieldCheck, 
  Leaf, 
  Package, 
  Check, 
  Eye,
  SlidersHorizontal,
  Coffee
} from 'lucide-react';

interface CatalogSectionProps {
  selectedCategory: ProductCategory;
  onSelectCategory: (category: ProductCategory) => void;
  selectedBrand?: string | null;
  onSelectBrand?: (brand: string | null) => void;
  onBackToHome?: () => void;
}

export const CatalogSection: React.FC<CatalogSectionProps> = ({
  selectedCategory,
  onSelectCategory,
  selectedBrand = null,
  onSelectBrand,
  onBackToHome,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [localBrand, setLocalBrand] = useState<string | null>(selectedBrand || null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [storeFilter, setStoreFilter] = useState<'all' | 'annen' | 'jako'>('all');

  const activeBrand = selectedBrand !== undefined ? selectedBrand : localBrand;
  const setActiveBrand = (brand: string | null) => {
    if (onSelectBrand) {
      onSelectBrand(brand);
    }
    setLocalBrand(brand);
  };

  const filterTabs: { key: ProductCategory; label: string; icon: React.ReactNode }[] = [
    { key: 'all', label: 'Alle Artikel', icon: <Package className="w-3.5 h-3.5" /> },
    { key: 'raw', label: 'RAW Sortiment', icon: <Flame className="w-3.5 h-3.5 text-[#10B981]" /> },
    { key: 'filters', label: 'Filter & Papers', icon: <Layers className="w-3.5 h-3.5 text-[#34D399]" /> },
    { key: 'headshop', label: 'Glasbongs & Rigs', icon: <FlaskConical className="w-3.5 h-3.5 text-teal-400" /> },
    { key: 'grinder', label: 'Grinder & Crusher', icon: <Cog className="w-3.5 h-3.5 text-emerald-400" /> },
    { key: 'smartshop', label: 'Smartshop Gear', icon: <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" /> },
    { key: 'cbd', label: 'Bio CBD & Hanf', icon: <Leaf className="w-3.5 h-3.5 text-[#10B981]" /> },
    { key: 'tea', label: 'Cannaline CBD Tee', icon: <Coffee className="w-3.5 h-3.5 text-lime-400" /> },
  ];

  const brandOptions = [
    'Alle Marken',
    'RAW',
    'OCB',
    'Cannaline',
    'Champ High',
    'Jelly Joker',
    "Granny's",
    'Best Buds',
    'Clipper',
    'Purize',
    'ActiTube',
    'Marie',
    'G-Rollz',
    'Hemper',
    'Green Monkey',
  ];

  const filteredProducts = PRODUCTS.filter((item) => {
    const matchesCategory = 
      selectedCategory === 'all' || 
      item.category === selectedCategory ||
      (selectedCategory === 'cbd' && item.category === 'tea');
    const matchesBrand = !activeBrand || activeBrand === 'Alle Marken' || item.brand === activeBrand;
    const matchesStore = 
      storeFilter === 'all' || 
      item.stockLocation === 'both' || 
      item.stockLocation === storeFilter;
    
    const query = searchQuery.trim().toLowerCase();
    const matchesSearch =
      query === '' ||
      item.title.toLowerCase().includes(query) ||
      item.brand.toLowerCase().includes(query) ||
      item.brief.toLowerCase().includes(query) ||
      item.categoryLabel.toLowerCase().includes(query) ||
      item.specs.some((s) => s.toLowerCase().includes(query));

    return matchesCategory && matchesBrand && matchesStore && matchesSearch;
  });

  const renderProductIcon = (category: string, brand?: string) => {
    if (brand === 'RAW') return <Flame className="w-10 h-10 text-[#C5A880]/80 group-hover:text-[#F6F4EE] transition-colors" />;
    if (brand === 'Champ High') return <Cog className="w-10 h-10 text-blue-400/80 group-hover:text-blue-200 transition-colors" />;
    if (brand === 'Jelly Joker' || brand === 'Hemper') return <FlaskConical className="w-10 h-10 text-teal-400/80 group-hover:text-teal-200 transition-colors" />;
    if (brand === 'Cannaline' || category === 'tea') return <Coffee className="w-10 h-10 text-lime-400/80 group-hover:text-lime-200 transition-colors" />;
    if (category === 'filters') return <Layers className="w-10 h-10 text-[#DFCAAB]/80 group-hover:text-[#F6F4EE] transition-colors" />;
    if (category === 'grinder') return <Cog className="w-10 h-10 text-amber-400/80 group-hover:text-amber-200 transition-colors" />;
    if (category === 'headshop') return <FlaskConical className="w-10 h-10 text-cyan-400/80 group-hover:text-cyan-200 transition-colors" />;
    if (category === 'cbd') return <Leaf className="w-10 h-10 text-emerald-400/80 group-hover:text-emerald-200 transition-colors" />;
    return <Package className="w-10 h-10 text-[#C5A880]/80 group-hover:text-[#F6F4EE] transition-colors" />;
  };

  return (
    <section className="py-8 md:py-14 bg-transparent min-h-screen" id="catalog-view">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Top Breadcrumb & Back Bar */}
        <div className="flex items-center justify-between gap-4 pb-6 mb-8 border-b border-white/10">
          {onBackToHome && (
            <button
              type="button"
              onClick={onBackToHome}
              className="inline-flex items-center gap-2 text-xs font-bold px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 text-[#DFDAD0] hover:text-[#F6F4EE] border border-white/10 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Zurück zur Startseite</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs text-[#8E9F94]">
            <span>Sortiment Graz:</span>
            <span className="font-heading font-bold text-[#F6F4EE] bg-[#12281D] px-2.5 py-1 rounded-full border border-white/10">
              {filteredProducts.length} Artikel
            </span>
          </div>
        </div>

        {/* Catalog Header */}
        <div className="mb-8">
          <span className="inline-flex items-center gap-1.5 text-xs font-mono font-bold tracking-widest text-[#10B981] uppercase mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            LOKALER SORTIMENTS-KATALOG // GRAZ
          </span>
          <h1 className="font-['Syne'] text-2xl sm:text-3xl md:text-4xl font-extrabold text-white mb-2">
            Sortiment &amp; Marken in Graz
          </h1>
          <p className="text-xs sm:text-sm text-white/60 max-w-3xl leading-relaxed">
            Offizielle Markenprodukte in unseren Fachgeschäften in der Annenstraße 68 (Hauptbahnhof) und Radetzkystraße 13 (Jakominiplatz).
            Alle Artikel vor Ort begutachten und direkt mitnehmen.
          </p>
        </div>

        {/* Clean Notice Banner (No Online Sale / In-Store Only) */}
        <div className="bg-[#121815] border border-[#10B981]/30 rounded-xl p-4 sm:p-5 mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#10B981]/20 text-[#10B981] flex items-center justify-center shrink-0 mt-0.5">
              <Info className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-['Syne'] font-bold text-white">
                Schaufenster-Katalog • Verkauf &amp; Beratung ausschließlich vor Ort in Graz
              </h4>
              <p className="text-xs text-white/60 mt-0.5 leading-relaxed font-['Geist']">
                Kein anonymer Online-Versand. Persönliche Fachberatung und Altersprüfung (18+) direkt in beiden Filialen.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 self-stretch sm:self-auto shrink-0">
            <span className="font-mono text-[10px] uppercase text-[#C5A880] bg-black/60 px-3 py-1.5 rounded-full border border-white/10">
              HBF: Mo–Fr 12–18
            </span>
            <span className="font-mono text-[10px] uppercase text-[#C5A880] bg-black/60 px-3 py-1.5 rounded-full border border-white/10">
              JAKO: Mo–Sa 12–18
            </span>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-5 scrollbar-none">
          {filterTabs.map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => {
                onSelectCategory(tab.key);
                if (tab.key === 'raw') {
                  setActiveBrand('RAW');
                }
              }}
              className={`inline-flex items-center gap-2 text-xs px-4 py-2 rounded-full font-heading font-bold uppercase tracking-wider whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === tab.key
                  ? 'bg-[#C5A880] text-[#07150D] shadow-md shadow-[#C5A880]/20'
                  : 'bg-white/5 text-[#DFDAD0] hover:text-white border border-white/10 hover:border-[#C5A880]/40'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-col lg:flex-row gap-3 justify-between items-stretch lg:items-center mb-8 p-3 rounded-2xl bg-black/40 border border-white/10">
          
          {/* Brand Filter */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0 scrollbar-none">
            <span className="font-mono text-[10px] text-[#8E9F94] uppercase tracking-wider px-2 shrink-0">
              Marke:
            </span>
            {brandOptions.map((brand) => {
              const isActive = activeBrand === brand || (!activeBrand && brand === 'Alle Marken');
              return (
                <button
                  key={brand}
                  type="button"
                  onClick={() => setActiveBrand(brand === 'Alle Marken' ? null : brand)}
                  className={`font-mono text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-full whitespace-nowrap transition-colors cursor-pointer shrink-0 ${
                    isActive
                      ? 'bg-[#C5A880] text-[#07150D] font-bold'
                      : 'bg-black/40 text-[#DFDAD0] hover:text-white border border-white/10 hover:border-[#C5A880]/40'
                  }`}
                >
                  {brand}
                </button>
              );
            })}
          </div>

          {/* Search Input & Store Filter */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Store availability quick toggle */}
            <select
              value={storeFilter}
              onChange={(e) => setStoreFilter(e.target.value as 'all' | 'annen' | 'jako')}
              className="px-3 py-1.5 bg-[#0F2218] border border-white/10 text-xs text-[#DFDAD0] rounded-lg font-mono uppercase focus:outline-none focus:border-[#C5A880]"
            >
              <option value="all">Alle Stores Graz</option>
              <option value="annen">Store 01 (HBF)</option>
              <option value="jako">Store 02 (JAKO)</option>
            </select>

            {/* Search Input */}
            <div className="relative min-w-[200px] sm:min-w-[240px]">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Artikel suchen..."
                className="w-full pl-10 pr-4 py-1.5 bg-[#0F2218] border border-white/10 focus:border-[#C5A880] rounded-lg text-xs text-white placeholder:text-white/40 focus:outline-none transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-white/50 hover:text-white"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

        </div>

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-16 bg-[#12281D]/60 rounded-2xl border border-white/10">
            <p className="text-sm text-[#DFDAD0] mb-3">Keine Artikel für diese Auswahl gefunden.</p>
            <button
              type="button"
              onClick={() => {
                onSelectCategory('all');
                setActiveBrand(null);
                setSearchQuery('');
                setStoreFilter('all');
              }}
              className="px-5 py-2.5 rounded-full text-xs font-semibold btn-gold cursor-pointer"
            >
              Filter zurücksetzen
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 mb-14">
            {filteredProducts.map((item) => (
              <article
                key={item.id}
                onClick={() => setSelectedProduct(item)}
                className="bg-[#0F2218]/90 border border-white/10 hover:border-[#C5A880]/50 rounded-2xl overflow-hidden flex flex-col justify-between transition-all duration-200 hover:-translate-y-1 hover:shadow-2xl hover:shadow-black/60 cursor-pointer group"
              >
                <div>
                  {/* Visual Header / Media */}
                  <div className={`relative h-48 sm:h-52 w-full ${item.imageUrl ? 'bg-white' : `bg-gradient-to-br ${item.mediaGradient}`} flex items-center justify-center overflow-hidden border-b border-white/10`}>
                    
                    {/* Store Availability Badge (Top Left) */}
                    <span className="absolute top-3 left-3 text-[10px] font-mono tracking-wider px-2 py-0.5 rounded-full border backdrop-blur-md z-10 bg-black/90 text-[#DFCAAB] border-[#C5A880]/40 inline-flex items-center gap-1.5 shadow-md">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880] pulse-dot-gold" />
                      {item.stockLocation === 'both' ? 'Beide Stores' : item.stockLocation === 'annen' ? 'HBF' : 'JAKO'}
                    </span>

                    {/* Brand Tag Top Right */}
                    <span className="absolute top-3 right-3 text-[10px] font-mono font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-black/90 text-white border border-white/20 z-10 shadow-md">
                      {item.brand}
                    </span>

                    {/* Real Product Image OR SVG Vector Icon Artwork */}
                    {item.imageUrl ? (
                      <div className="w-full h-full flex items-center justify-center relative p-3">
                        <img
                          src={item.imageUrl}
                          alt={item.title}
                          className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    ) : (
                      <div className="drop-shadow-md group-hover:scale-110 transition-transform duration-200">
                        {renderProductIcon(item.category, item.brand)}
                      </div>
                    )}
                  </div>

                  {/* Body Content */}
                  <div className="p-4 sm:p-5">
                    <span className="text-[10px] font-mono tracking-widest text-[#C5A880] uppercase block mb-1">
                      {item.categoryLabel}
                    </span>

                    <h3 className="font-heading text-sm sm:text-base font-bold text-[#F6F4EE] leading-snug mb-2 line-clamp-2 group-hover:text-[#DFCAAB] transition-colors">
                      {item.title}
                    </h3>

                    <p className="text-xs text-[#8E9F94] leading-relaxed mb-3 line-clamp-2">
                      {item.brief}
                    </p>

                    {/* Specs Pills */}
                    <div className="flex flex-wrap gap-1 mb-3">
                      {item.specs.slice(0, 2).map((spec, idx) => (
                        <span
                          key={idx}
                          className="font-mono text-[9px] uppercase tracking-wider bg-black/40 border border-white/10 text-[#DFDAD0] px-2 py-0.5 rounded"
                        >
                          {spec}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Footer Status & Detail Action - Badge Swapped to Bottom Left */}
                <div className="p-4 sm:p-5 pt-0">
                  <div className="flex items-center justify-between text-xs pt-2.5 border-t border-white/10">
                    {item.badge ? (
                      <span
                        className={`text-[10px] font-bold tracking-wider px-2 py-0.5 rounded-md border ${
                          item.badgeType === 'raw'
                            ? 'bg-amber-950/70 text-amber-200 border-amber-600/40'
                            : item.badgeType === 'champhigh'
                            ? 'bg-blue-950/70 text-blue-200 border-blue-500/40'
                            : item.badgeType === 'gold'
                            ? 'bg-[#C5A880]/20 text-[#DFCAAB] border-[#C5A880]/40'
                            : 'bg-white/5 text-[#DFDAD0] border-white/10'
                        }`}
                      >
                        {item.badge}
                      </span>
                    ) : (
                      <span className="text-[10px] font-semibold text-[#8E9F94] bg-white/5 border border-white/10 px-2 py-0.5 rounded">
                        Originalware
                      </span>
                    )}
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#DFCAAB] group-hover:underline">
                      <Eye className="w-3 h-3" />
                      Details
                    </span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}

        {/* Bottom Store Note */}
        <div className="bg-[#0F2218]/90 border border-white/10 rounded-2xl p-6 text-center max-w-2xl mx-auto shadow-lg">
          <h4 className="font-heading font-bold text-base text-[#F6F4EE] mb-2">
            Persönliche Begutachtung in Graz
          </h4>
          <p className="text-xs text-[#8E9F94] leading-relaxed mb-4">
            Besuchen Sie uns direkt vor Ort: Annenstraße 68 (Hauptbahnhof) oder Radetzkystraße 13 (Jakominiplatz).
            Wir halten alle Artikel vorrätig und beraten Sie persönlich.
          </p>
          {onBackToHome && (
            <button
              type="button"
              onClick={onBackToHome}
              className="inline-flex items-center gap-2 text-xs font-bold px-5 py-2.5 rounded-full btn-gold cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Zurück zur Startseite</span>
            </button>
          )}
        </div>

      </div>

      {/* Product Detail Modal */}
      <CatalogItemModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />
    </section>
  );
};
