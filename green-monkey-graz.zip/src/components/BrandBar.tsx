import React from 'react';
import { BRAND_SHOWCASE } from '../data/storeData';
import { Sparkles, ShieldCheck } from 'lucide-react';
import { ProductCategory } from '../types';

interface BrandBarProps {
  activeBrand: string | null;
  onSelectBrand: (brandName: string | null) => void;
  onSelectCategory: (category: ProductCategory) => void;
}

export const BrandBar: React.FC<BrandBarProps> = ({
  activeBrand,
  onSelectBrand,
  onSelectCategory,
}) => {
  const handleBrandClick = (brandName: string, category: string) => {
    if (activeBrand === brandName) {
      onSelectBrand(null);
    } else {
      onSelectBrand(brandName);
      if (category === 'raw') {
        onSelectCategory('raw');
      } else if (category === 'filters') {
        onSelectCategory('filters');
      } else if (category === 'grinder') {
        onSelectCategory('grinder');
      } else if (category === 'headshop') {
        onSelectCategory('headshop');
      } else if (category === 'cbd') {
        onSelectCategory('cbd');
      } else if (category === 'tea') {
        onSelectCategory('tea');
      }
      const catalogEl = document.getElementById('catalog');
      if (catalogEl) {
        catalogEl.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <section className="py-12 bg-[#0B1A12] border-t border-b border-white/10" id="brands">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <span className="inline-block text-xs font-bold tracking-widest text-[#C5A880] uppercase mb-1 font-heading">
              MARKEN-PORTFOLIO IN GRAZ
            </span>
            <h3 className="font-heading text-lg sm:text-xl font-bold text-[#F6F4EE]">
              Offizielle Top-Marken im Grazer Sortiment
            </h3>
          </div>
          <div className="flex items-center gap-2 bg-black/40 px-3.5 py-1.5 rounded-full border border-white/10 text-xs text-[#8E9F94]">
            <ShieldCheck className="w-3.5 h-3.5 text-[#C5A880]" />
            <span>100% Originalware autorisierter Hersteller • Nur vor Ort</span>
          </div>
        </div>

        {/* Brand Chips Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {BRAND_SHOWCASE.map((brand) => {
            const isSelected = activeBrand === brand.name;

            return (
              <button
                key={brand.name}
                type="button"
                onClick={() => handleBrandClick(brand.name, brand.category)}
                className={`flex flex-col items-center justify-center p-3.5 rounded-xl border text-center transition-all cursor-pointer group ${
                  isSelected
                    ? 'bg-[#C5A880] text-[#07150D] border-[#C5A880] shadow-md shadow-[#C5A880]/30 font-bold'
                    : 'bg-black/30 border-white/10 hover:border-[#C5A880]/50 hover:bg-white/5'
                }`}
              >
                <span
                  className={`font-heading font-bold text-sm sm:text-base tracking-tight mb-0.5 ${
                    isSelected ? 'text-[#07150D]' : 'text-[#F6F4EE] group-hover:text-[#C5A880]'
                  }`}
                >
                  {brand.name}
                </span>

                <span className={`text-[11px] line-clamp-1 mb-1.5 ${isSelected ? 'text-[#07150D]/80' : 'text-[#8E9F94]'}`}>
                  {brand.tagline.split(',')[0]}
                </span>
                
                <span
                  className={`text-[9px] uppercase tracking-wider px-2 py-0.5 rounded-full font-semibold ${
                    isSelected
                      ? 'bg-black/20 text-[#07150D]'
                      : 'bg-white/5 text-[#DFCAD0] border border-white/10'
                  }`}
                >
                  {brand.badge}
                </span>
              </button>
            );
          })}
        </div>

        {activeBrand && (
          <div className="mt-4 flex items-center justify-between bg-black/40 px-4 py-2.5 rounded-xl border border-white/10 text-xs">
            <span className="text-[#DFDAD0]">
              Gefiltert nach Marke: <strong className="text-[#C5A880]">{activeBrand}</strong>
            </span>
            <button
              type="button"
              onClick={() => onSelectBrand(null)}
              className="text-[#DFCAAB] hover:underline uppercase text-[11px] font-bold cursor-pointer"
            >
              Filter zurücksetzen
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
