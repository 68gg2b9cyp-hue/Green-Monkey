import React from 'react';
import { ShieldCheck, Award, Microscope, Leaf } from 'lucide-react';

export const GuideSection: React.FC = () => {
  return (
    <section className="py-16 md:py-24 border-t border-white/10" id="guide">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="bg-[#12281D]/90 backdrop-blur-md border border-white/12 rounded-3xl p-6 sm:p-10 lg:p-14 shadow-2xl shadow-black/40">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
            
            {/* Left Content */}
            <div className="lg:col-span-7 flex flex-col">
              <span className="inline-block text-xs font-bold tracking-widest text-[#C5A880] uppercase mb-2 font-heading">
                WISSEN &amp; TRANSPARENZ
              </span>
              <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl font-bold text-[#F6F4EE] mb-4">
                Was Sie über CBD in Österreich wissen sollten
              </h2>
              <p className="text-sm sm:text-base text-[#DFDAD0] leading-relaxed mb-8">
                Cannabidiol (CBD) ist ein natürlicher, nicht-psychoaktiver Bestandteil der Nutzhanfpflanze.
                Im Gegensatz zu THC erzeugt es keinerlei berauschende Wirkung, macht nicht abhängig und ist
                in Österreich legal erhältlich.
              </p>

              <div className="flex flex-col gap-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center shrink-0 text-[#C5A880]">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-[#F6F4EE] mb-1">
                      100% Gesetzeskonform in Österreich
                    </h4>
                    <p className="text-xs sm:text-sm text-[#8E9F94] leading-relaxed">
                      Unsere Produkte unterliegen den österreichischen Richtlinien (§ 1 Abs 1 Z 2 SMG) und weisen ausnahmslos
                      einen THC-Gehalt von unter 0,3% auf.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center shrink-0 text-emerald-400">
                    <Microscope className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-[#F6F4EE] mb-1">
                      Unabhängige HPLC-Laboranalysen
                    </h4>
                    <p className="text-xs sm:text-sm text-[#8E9F94] leading-relaxed">
                      Jede Charge wird von akkreditierten europäischen Prüflaboren auf Reinheit, Cannabinoidprofil,
                      Schwermetalle, Pestizide und mikrobiologische Sicherheit getestet.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center shrink-0 text-[#DFCAAB]">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-[#F6F4EE] mb-1">
                      Individuelle Abstimmung &amp; Beratung
                    </h4>
                    <p className="text-xs sm:text-sm text-[#8E9F94] leading-relaxed">
                      5% zur leichten Tagesbalance, 10% bei Stress &amp; Schlafschwierigkeiten, 20% für gezielte
                      regenerative Unterstützung. In unseren Stores beraten wir Sie gerne individuell.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Card: Reinheitsversprechen */}
            <div className="lg:col-span-5 bg-gradient-to-br from-[#1B3827] via-[#142C1E] to-[#0D1D14] border border-[#C5A880]/50 rounded-2xl p-7 sm:p-9 text-center shadow-2xl shadow-black/40">
              <div className="inline-flex items-center gap-1.5 text-xs font-bold tracking-widest text-[#DFCAAB] border border-[#C5A880]/30 px-3 py-1 rounded-full mb-5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#C5A880]" />
                ÖSTERREICHISCHE QUALITÄT
              </div>

              <h3 className="font-heading text-xl sm:text-2xl font-bold text-[#F6F4EE] mb-3">
                Green Monkey Reinheitsversprechen
              </h3>

              <p className="text-xs sm:text-sm text-[#DFDAD0] leading-relaxed mb-6">
                Transparenz ist unser höchstes Gut. In beiden Grazer Filialen erhalten Sie auf Wunsch jederzeit
                Einsicht in die aktuellen Analysezertifikate der jeweiligen Chargen.
              </p>

              <div className="flex flex-wrap justify-center gap-2">
                <span className="inline-flex items-center gap-1 text-xs bg-black/40 border border-white/10 text-[#DFCAAB] px-3 py-1.5 rounded-full">
                  <Leaf className="w-3.5 h-3.5 text-emerald-400" />
                  100% Bio Hanf
                </span>
                <span className="inline-flex items-center gap-1 text-xs bg-black/40 border border-white/10 text-[#DFCAAB] px-3 py-1.5 rounded-full">
                  <Microscope className="w-3.5 h-3.5 text-emerald-400" />
                  HPLC Laborgeprüft
                </span>
                <span className="inline-flex items-center gap-1 text-xs bg-black/40 border border-white/10 text-[#DFCAAB] px-3 py-1.5 rounded-full">
                  <Award className="w-3.5 h-3.5 text-emerald-400" />
                  Ohne Zusatzstoffe
                </span>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};
