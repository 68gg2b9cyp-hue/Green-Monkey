import React from 'react';
import logoImg from '../assets/images/green_monkey_logo_1790017011803.jpg';

interface GreenMonkeyLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showRing?: boolean;
}

export const GreenMonkeyLogo: React.FC<GreenMonkeyLogoProps> = ({
  size = 'md',
  className = '',
  showRing = true,
}) => {
  const sizeMap = {
    xs: 'w-7 h-7',
    sm: 'w-9 h-9',
    md: 'w-11 h-11 sm:w-12 sm:h-12',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24 sm:w-28 sm:h-28',
  };

  return (
    <div
      className={`relative rounded-full shrink-0 flex items-center justify-center overflow-hidden transition-transform duration-300 ${sizeMap[size]} ${
        showRing
          ? 'p-[1.5px] bg-gradient-to-tr from-[#C5A880] via-[#34D399] to-[#C5A880] shadow-lg shadow-black/60'
          : 'bg-black'
      } ${className}`}
    >
      <img
        src={logoImg}
        alt="Green Monkey Cannabis Shop"
        className="w-full h-full object-cover rounded-full bg-black"
        referrerPolicy="no-referrer"
        loading="eager"
      />
    </div>
  );
};
