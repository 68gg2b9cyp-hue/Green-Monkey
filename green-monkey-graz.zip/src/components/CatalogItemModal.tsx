import React from 'react';
import { Product } from '../types';
import { STORES } from '../data/storeData';
import { X, CheckCircle2, MapPin, Phone, ShieldCheck, Clock, Store, Flame, Layers, FlaskConical, Cog, Leaf, Package, Coffee } from 'lucide-react';

interface CatalogItemModalProps {
  product: Product | null;
  onClose: () => void;
}

export const CatalogItemModal: React.FC<CatalogItemModalProps> = ({
  product,
  onClose,
}) => {
  if (!product) return null;

  const renderCategoryIcon = (category: string, brand?: string) => {
    if (brand === 'RAW') return <Flame className="w-8 h-8 text-[#C5A880]" />;
    if (brand === 'Champ High') return <Cog className="w-8 h-8 text-blue-400" />;
    if (brand === 'Jelly Joker' || brand === 'Hemper') return <FlaskConical className="w-8 h-8 text-teal-400" />;
    if (brand === 'Cannaline' || category === 'tea') return <Coffee className="w-8 h-8 text-emerald-400" />;
    if (category === 'filters') return <Layers className="w-8 h-8 text-[#DFCAAB]" />;
    if (category === 'grinder') return <Cog className="w-8 h-8 text-amber-400" />;
    if (category === 'headshop') return <FlaskConical className="w-8 h-8 text-cyan-400" />;
    if (category === 'cbd') return <Leaf className="w-8 h-8 text-emerald-400" />;
    return <Package className="w-8 h-8 text-[#C5A880]" />;
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto bg-[#0F2218]/95 border border-[#C5A880]/30 rounded-3xl p-6 sm:p-8 shadow-2xl text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-white/60 hover:text-white bg-black/40 hover:bg-black/80 border border-white/10 transition-colors cursor-pointer z-10"
          aria-label="Schließen"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Product Photo Showcase if available */}
        {product.imageUrl && (
          <div className="w-full h-52 sm:h-64 rounded-2xl bg-white border border-white/10 mb-6 p-4 flex items-center justify-center overflow-hidden">
            <img
              src={product.imageUrl}
              alt={product.title}
              className="max-h-full max-w-full object-contain rounded"
              referrerPolicy="no-referrer"
            />
          </div>
        )}

        {/* Visual Header / Brand */}
        <div className="flex items-center gap-4 mb-4">
          <div className="w-14 h-14 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-center shrink-0 overflow-hidden">
            {product.imageUrl ? (
              <img
                src={product.imageUrl}
                alt={product.title}
                className="w-full h-full object-contain p-1"
                referrerPolicy="no-referrer"
              />
            ) : (
              renderCategoryIcon(product.category, product.brand)
            )}
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-[10px] font-bold tracking-widest uppercase text-[#DFCAAB] bg-[#C5A880]/15 border border-[#C5A880]/30 px-2.5 py-0.5 rounded-full">
                {product.brand}
              </span>
              <span className="text-[10px] text-[#8E9F94] uppercase tracking-wider">
                {product.categoryLabel}
              </span>
            </div>
            <h3 className="font-heading text-lg sm:text-xl font-bold text-[#F6F4EE] leading-snug">
              {product.title}
            </h3>
          </div>
        </div>

        {/* In-Store Availability & Stock Status */}
        <div className="flex items-center justify-between p-3.5 bg-black/30 border border-white/10 rounded-2xl mb-5 text-xs">
          <div>
            <span className="text-[10px] text-[#8E9F94] uppercase tracking-wider block font-semibold">Verkauf &amp; Beratung</span>
            <strong className="text-sm font-heading font-bold text-[#F6F4EE] flex items-center gap-1.5">
              <Store className="w-4 h-4 text-[#C5A880]" />
              Direkt vor Ort in Graz
            </strong>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-[#8E9F94] uppercase tracking-wider block font-semibold">Verfügbarkeit</span>
            <span className="text-xs font-bold text-[#DFCAAB] inline-flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880] pulse-dot-gold" />
              {product.stockNote}
            </span>
          </div>
        </div>

        {/* Brief description */}
        <p className="text-xs sm:text-sm text-[#DFDAD0] leading-relaxed mb-6">
          {product.brief}
        </p>

        {/* Specs */}
        <div className="mb-6">
          <span className="text-xs font-bold text-[#C5A880] uppercase tracking-wider block mb-2 font-heading">
            DETAILS &amp; BESONDERHEITEN
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {product.specs.map((spec, i) => (
              <div
                key={i}
                className="flex items-center gap-2 p-2.5 rounded-xl bg-black/30 border border-white/10 text-xs text-[#DFDAD0]"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-[#C5A880] shrink-0" />
                <span>{spec}</span>
              </div>
            ))}
          </div>
        </div>

        {/* In-Store Locations in Graz */}
        <div className="mb-6">
          <span className="text-xs font-bold text-[#8E9F94] uppercase tracking-wider block mb-2 font-heading">
            VERFÜGBAR IN DEN GRAZER FILIALEN
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {STORES.map((s) => (
              <div
                key={s.id}
                className="p-3 bg-black/40 border border-white/10 rounded-xl text-xs"
              >
                <span className="font-heading font-bold text-[#F6F4EE] block mb-0.5">
                  {s.shortName}
                </span>
                <span className="text-[11px] text-[#8E9F94] block mb-1">
                  {s.address}
                </span>
                <span className="font-mono text-[10px] text-[#C5A880]">
                  {s.hoursWeekday}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Notice */}
        <div className="flex items-center gap-2 text-[11px] text-[#8E9F94] border-t border-white/10 pt-4 mb-5">
          <ShieldCheck className="w-4 h-4 text-[#C5A880] shrink-0" />
          <span>Kein Online-Versand. Altersprüfung (18+) bei Abholung im Store.</span>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-3 rounded-full text-xs font-bold uppercase tracking-wider btn-gold cursor-pointer text-center"
        >
          Schließen
        </button>
      </div>
    </div>
  );
};
