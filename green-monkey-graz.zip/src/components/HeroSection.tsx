import React, { useState, useEffect } from 'react';
import { ArrowRight, MapPin, ShieldCheck, Sparkles, Package, Leaf, Award, Clock, ChevronRight } from 'lucide-react';
import { GreenMonkeyLogo } from './GreenMonkeyLogo';

interface HeroSectionProps {
  onOpenCatalog: () => void;
  onScrollToStores?: () => void;
}

interface StoreStatus {
  isOpen: boolean;
  statusLabel: string;
}

function getStoreLiveStatus(store: 'annen' | 'jako'): StoreStatus {
  try {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Europe/Vienna',
      weekday: 'short',
      hour: 'numeric',
      minute: 'numeric',
      hour12: false,
    });
    const parts = formatter.formatToParts(now);
    let weekday = '';
    let hour = 0;
    let minute = 0;
    for (const p of parts) {
      if (p.type === 'weekday') weekday = p.value;
      if (p.type === 'hour') hour = parseInt(p.value, 10);
      if (p.type === 'minute') minute = parseInt(p.value, 10);
    }
    const currentMinutes = hour * 60 + minute;
    // Both open 12:00 to 18:00
    const isWithinHours = currentMinutes >= 12 * 60 && currentMinutes < 18 * 60;

    if (store === 'annen') {
      // Annenstraße: Mo-Fr 12:00 - 18:00
      const isWeekday = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].includes(weekday);
      const isOpen = isWeekday && isWithinHours;
      return {
        isOpen,
        statusLabel: isOpen ? 'Jetzt geöffnet' : 'Geschlossen',
      };
    } else {
      // Radetzkystraße: Mo-Sa 12:00 - 18:00
      const isMonToSat = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].includes(weekday);
      const isOpen = isMonToSat && isWithinHours;
      return {
        isOpen,
        statusLabel: isOpen ? 'Jetzt geöffnet' : 'Geschlossen',
      };
    }
  } catch {
    return {
      isOpen: false,
      statusLabel: 'Geschlossen',
    };
  }
}

function getGrazTimeFormatted(): string {
  try {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat('de-AT', {
      timeZone: 'Europe/Vienna',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });
    return formatter.format(now);
  } catch {
    return '';
  }
}

export const HeroSection: React.FC<HeroSectionProps> = ({ 
  onOpenCatalog,
  onScrollToStores
}) => {
  const [annenStatus, setAnnenStatus] = useState<StoreStatus>(() => getStoreLiveStatus('annen'));
  const [jakoStatus, setJakoStatus] = useState<StoreStatus>(() => getStoreLiveStatus('jako'));
  const [localTimeStr, setLocalTimeStr] = useState<string>(() => getGrazTimeFormatted());

  useEffect(() => {
    const update = () => {
      setAnnenStatus(getStoreLiveStatus('annen'));
      setJakoStatus(getStoreLiveStatus('jako'));
      setLocalTimeStr(getGrazTimeFormatted());
    };
    update();
    const timer = setInterval(update, 30000);
    return () => clearInterval(timer);
  }, []);

  const handleStoresClick = () => {
    if (onScrollToStores) {
      onScrollToStores();
    } else {
      const el = document.getElementById('stores');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      className="relative pt-12 pb-16 md:pt-20 md:pb-24 overflow-hidden border-b border-white/10" 
      id="hero"
      style={{
        background: 'linear-gradient(180deg, #2d3a20 0%, #1f2b17 55%, #131c11 100%)'
      }}
    >
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-[#C5A880]/15 via-[#2d3a20]/30 to-transparent blur-3xl pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Main Hero Copy (Left) */}
          <div className="lg:col-span-7 flex flex-col text-left">
            
            {/* Top Badge */}
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-[#12281D] border border-[#C5A880]/40 text-[#DFCAAB] text-xs font-semibold self-start mb-6 shadow-lg shadow-black/40">
              <span className="w-2 h-2 rounded-full bg-[#C5A880] pulse-dot-gold" />
              <span className="tracking-wider uppercase text-[11px] font-bold">Offizieller Fachhandel Graz</span>
              <span className="text-white/20">•</span>
              <span className="text-[#8E9F94] text-[11px]">2 Standorte: HBF &amp; Jakomini</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-syne font-extrabold text-3xl sm:text-5xl lg:text-6xl text-[#F6F4EE] leading-[1.12] tracking-tight mb-6">
              <span className="block drop-shadow-sm">Premium CBD, Headshop &amp;</span>
              <span className="relative inline-block mt-2 font-black">
                <span className="bg-gradient-to-r from-[#FFF6E9] via-[#E2C898] to-[#C5A880] bg-clip-text text-transparent drop-shadow-[0_2px_14px_rgba(197,168,128,0.35)]">
                  Rauchkultur in Graz
                </span>
                <span className="block h-1 w-28 sm:w-36 mt-2 rounded-full bg-gradient-to-r from-[#C5A880] via-[#DFCAAB] to-transparent shadow-[0_0_10px_rgba(197,168,128,0.4)]" />
              </span>
            </h1>

            {/* Subtext description */}
            <p className="text-base sm:text-lg text-[#DFDAD0] leading-relaxed max-w-2xl mb-8">
              Ihr zertifizierter Fachhändler für laborgeprüfte Bio-CBD Öle, offizielle RAW® Headshop-Kollektionen, Borosilikat-Glasbongs und Qualitätsfilter. Kein anonymer Online-Versand – sondern echte Beratung und sofortige Verfügbarkeit vor Ort in Graz.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 mb-10">
              <button
                type="button"
                onClick={onOpenCatalog}
                className="btn-gold px-7 py-3.5 rounded-full text-sm font-bold inline-flex items-center gap-2.5 cursor-pointer"
              >
                <Package className="w-4 h-4" />
                <span>Katalog ansehen (50+ Artikel)</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={handleStoresClick}
                className="btn-outline-gold px-6 py-3.5 rounded-full text-sm font-semibold inline-flex items-center gap-2 bg-white/5 cursor-pointer"
              >
                <MapPin className="w-4 h-4 text-[#C5A880]" />
                <span>Filialen &amp; Öffnungszeiten</span>
              </button>
            </div>

            {/* Quality Checkpoints */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 border-t border-white/10">
              <div className="flex items-center gap-2 text-xs text-[#DFDAD0]">
                <ShieldCheck className="w-4 h-4 text-[#C5A880] shrink-0" />
                <span>100% Originalware</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-[#DFDAD0]">
                <Leaf className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>&lt; 0,3% THC (§1 SMG)</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-[#DFDAD0]">
                <MapPin className="w-4 h-4 text-[#DFCAAB] shrink-0" />
                <span>2x Filialen in Graz</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-[#DFDAD0]">
                <Award className="w-4 h-4 text-[#C5A880] shrink-0" />
                <span>Ab 18 Jahren</span>
              </div>
            </div>

          </div>

          {/* Right Showcase: Two Store Branch Cards */}
          <div className="lg:col-span-5 flex flex-col gap-3.5 justify-center w-full max-w-md mx-auto">
            
            {/* Card 1: Annenstraße 68 (Hauptbahnhof) */}
            <div 
              onClick={handleStoresClick}
              className="relative rounded-2xl p-5 border border-[#C5A880]/30 hover:border-[#C5A880]/70 transition-all duration-300 shadow-xl shadow-black/60 group cursor-pointer overflow-hidden"
              style={{ 
                backgroundColor: '#092209',
                background: 'linear-gradient(145deg, #092209 0%, #0d2c12 55%, #051607 100%)'
              }}
            >
              {/* Subtle top golden gloss line */}
              <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#C5A880]/40 to-transparent" />

              <div className="flex items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#C5A880]/15 border border-[#C5A880]/30 flex items-center justify-center text-[#C5A880] font-heading font-bold text-xs">
                    01
                  </div>
                  <div>
                    <h3 className="font-heading font-bold text-base text-[#F6F4EE] group-hover:text-[#C5A880] transition-colors leading-tight">
                      Filiale Hauptbahnhof
                    </h3>
                    <span className="text-[10px] text-[#C5A880] font-mono tracking-wider uppercase font-semibold">
                      Annenstraße • Flagship
                    </span>
                  </div>
                </div>

                {/* Live Status Lamp / Bulb */}
                {annenStatus.isOpen ? (
                  <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-emerald-950/90 border border-emerald-500/50 text-emerald-300 text-xs font-bold shadow-[0_0_12px_rgba(16,185,129,0.35)] shrink-0">
                    <span className="relative flex h-2.5 w-2.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400 shadow-[0_0_8px_#34D399,0_0_14px_#10B981]" />
                    </span>
                    <span>Jetzt geöffnet</span>
                  </div>
                ) : (
                  <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-black/60 border border-white/10 text-neutral-400 text-xs font-medium shrink-0">
                    <span className="inline-flex rounded-full h-2.5 w-2.5 bg-neutral-600 border border-neutral-500/60" />
                    <span>Geschlossen</span>
                  </div>
                )}
              </div>

              {/* Address */}
              <div className="flex items-start gap-2 text-xs sm:text-sm text-[#F6F4EE] mb-1.5 pl-1">
                <MapPin className="w-4 h-4 text-[#C5A880] shrink-0 mt-0.5" />
                <div className="leading-snug">
                  <span className="font-semibold text-[#F6F4EE]">Annenstraße 68</span>
                  <span className="text-[#8E9F94] text-xs ml-1.5">8020 Graz (Esperantoplatz)</span>
                </div>
              </div>

              {/* Schedule Box */}
              <div className="bg-black/45 rounded-xl p-3 border border-white/8 mt-2 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#8E9F94] flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#C5A880]" />
                    <span>Öffnungszeiten:</span>
                  </span>
                  <span className="font-mono font-bold text-[#F6F4EE]">
                    Mo–Fr: 12:00 – 18:00
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] pt-1 border-t border-white/5 text-[#8E9F94]">
                  <span>Samstag &amp; Sonntag:</span>
                  <span className="text-neutral-400 font-medium">Geschlossen</span>
                </div>
              </div>

              {/* Bottom Quick Action Link */}
              <div className="mt-3 flex items-center justify-between text-[11px] text-[#DFCAAB] group-hover:text-white transition-colors pl-1">
                <span className="text-[#8E9F94] text-[11px]">Bim 1, 3, 6, 7 direkt vor Ort</span>
                <span className="inline-flex items-center gap-1 font-semibold text-[#C5A880]">
                  <span>Filiale anzeigen</span>
                  <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </span>
              </div>
            </div>

            {/* Card 2: Radetzkystraße 13 (Jakominiplatz) */}
            <div 
              onClick={handleStoresClick}
              className="relative rounded-2xl p-5 border border-[#C5A880]/30 hover:border-[#C5A880]/70 transition-all duration-300 shadow-xl shadow-black/60 group cursor-pointer overflow-hidden"
              style={{ 
                backgroundColor: '#092209',
                background: 'linear-gradient(145deg, #092209 0%, #0d2c12 55%, #051607 100%)'
              }}
            >
              {/* Subtle top golden gloss line */}
              <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#C5A880]/40 to-transparent" />

              <div className="flex items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#C5A880]/15 border border-[#C5A880]/30 flex items-center justify-center text-[#C5A880] font-heading font-bold text-xs">
                    02
                  </div>
                  <div>
                    <h3 className="font-heading font-bold text-base text-[#F6F4EE] group-hover:text-[#C5A880] transition-colors leading-tight">
                      Filiale Jakominiplatz
                    </h3>
                    <span className="text-[10px] text-[#C5A880] font-mono tracking-wider uppercase font-semibold">
                      Radetzkystraße • City Center
                    </span>
                  </div>
                </div>

                {/* Live Status Lamp / Bulb */}
                {jakoStatus.isOpen ? (
                  <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-emerald-950/90 border border-emerald-500/50 text-emerald-300 text-xs font-bold shadow-[0_0_12px_rgba(16,185,129,0.35)] shrink-0">
                    <span className="relative flex h-2.5 w-2.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400 shadow-[0_0_8px_#34D399,0_0_14px_#10B981]" />
                    </span>
                    <span>Jetzt geöffnet</span>
                  </div>
                ) : (
                  <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-black/60 border border-white/10 text-neutral-400 text-xs font-medium shrink-0">
                    <span className="inline-flex rounded-full h-2.5 w-2.5 bg-neutral-600 border border-neutral-500/60" />
                    <span>Geschlossen</span>
                  </div>
                )}
              </div>

              {/* Address */}
              <div className="flex items-start gap-2 text-xs sm:text-sm text-[#F6F4EE] mb-1.5 pl-1">
                <MapPin className="w-4 h-4 text-[#C5A880] shrink-0 mt-0.5" />
                <div className="leading-snug">
                  <span className="font-semibold text-[#F6F4EE]">Radetzkystraße 13</span>
                  <span className="text-[#8E9F94] text-xs ml-1.5">8010 Graz (Jakominiplatz)</span>
                </div>
              </div>

              {/* Schedule Box */}
              <div className="bg-black/45 rounded-xl p-3 border border-white/8 mt-2 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#8E9F94] flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#C5A880]" />
                    <span>Öffnungszeiten:</span>
                  </span>
                  <span className="font-mono font-bold text-[#F6F4EE]">
                    Mo–Sa: 12:00 – 18:00
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] pt-1 border-t border-white/5 text-[#8E9F94]">
                  <span>Sonntag &amp; Feiertage:</span>
                  <span className="text-neutral-400 font-medium">Geschlossen</span>
                </div>
              </div>

              {/* Bottom Quick Action Link */}
              <div className="mt-3 flex items-center justify-between text-[11px] text-[#DFCAAB] group-hover:text-white transition-colors pl-1">
                <span className="text-[#8E9F94] text-[11px]">1 Min. Gehweg vom Jakominiplatz</span>
                <span className="inline-flex items-center gap-1 font-semibold text-[#C5A880]">
                  <span>Filiale anzeigen</span>
                  <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </span>
              </div>
            </div>

            {/* Live Time & Quick Info Footer */}
            <div className="flex items-center justify-between px-2 pt-1 text-[11px] text-[#8E9F94]">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#C5A880] animate-pulse" />
                <span>Ortszeit Graz: <strong className="text-[#DFDAD0] font-mono">{localTimeStr || '12:00'} Uhr</strong></span>
              </span>
              <span className="text-[#C5A880]/90 font-medium">✨ 2 Filialen in Graz</span>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
