import React from 'react';
import { StoreId } from '../types';
import { STORES } from '../data/storeData';
import { MapPin, Clock, Phone, Mail, Navigation, TrainTrack } from 'lucide-react';

interface StoresSectionProps {
  activeStore: StoreId;
  onSelectStore: (id: StoreId) => void;
}

export const StoresSection: React.FC<StoresSectionProps> = ({
  activeStore,
  onSelectStore,
}) => {
  const currentStore = STORES.find((s) => s.id === activeStore) || STORES[0];

  return (
    <section className="py-16 md:py-24 border-t border-white/10 relative" id="stores">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="inline-block text-xs font-bold tracking-widest text-[#C5A880] uppercase mb-2 font-heading">
            STANDORTE IN GRAZ
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl font-bold text-[#F6F4EE] mb-3">
            2x Zentrale Filialen in Graz
          </h2>
          <p className="text-sm sm:text-base text-[#DFDAD0] leading-relaxed">
            Besuchen Sie uns direkt vor Ort. Großes Sortiment zum Anfassen, Vergleichen und diskreten Mitnehmen.
          </p>
        </div>

        {/* Store Switch Tabs */}
        <div className="flex justify-center gap-3 mb-10 flex-wrap">
          {STORES.map((store, index) => {
            const isActive = activeStore === store.id;
            return (
              <button
                key={store.id}
                type="button"
                onClick={() => onSelectStore(store.id)}
                className={`inline-flex items-center gap-2.5 px-6 py-3 rounded-full text-xs sm:text-sm font-heading font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#C5A880] text-[#07150D] shadow-lg shadow-[#C5A880]/25'
                    : 'bg-black/30 text-[#DFDAD0] hover:text-white border border-white/10 hover:border-[#C5A880]/40'
                }`}
              >
                <span
                  className={`w-5 h-5 rounded-full text-[10px] font-mono font-bold flex items-center justify-center ${
                    isActive ? 'bg-[#07150D] text-[#C5A880]' : 'bg-white/10 text-white'
                  }`}
                >
                  0{index + 1}
                </span>
                <span>{store.shortName} • {store.address}</span>
              </button>
            );
          })}
        </div>

        {/* Store Detail Content Grid */}
        <div className="bg-[#12281D]/90 border border-white/10 rounded-3xl p-6 sm:p-8 lg:p-10 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
            
            {/* Store Meta Box */}
            <div className="lg:col-span-6 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold font-mono tracking-widest text-[#C5A880] uppercase block mb-1">
                  {currentStore.stationCode} • {currentStore.tagline}
                </span>

                <h3 className="font-heading text-2xl sm:text-3xl font-bold text-[#F6F4EE] mb-2">
                  {currentStore.name}
                </h3>

                <p className="text-sm text-[#DFDAD0] flex items-center gap-2 mb-4">
                  <MapPin className="w-4 h-4 text-[#C5A880]" />
                  {currentStore.address}, {currentStore.postalCode} {currentStore.city}
                </p>

                <p className="text-xs sm:text-sm text-[#8E9F94] leading-relaxed mb-6">
                  {currentStore.id === 'annen'
                    ? 'Nur wenige Gehminuten vom Grazer Hauptbahnhof entfernt. Unser geräumiger Flagship-Store mit maximaler Auswahl an Bongs, Grinder-Kollektionen, Aktivkohlefiltern und vollem CBD-Sortiment.'
                    : 'Mitten im zentralen Verkehrsknotenpunkt der Grazer Innenstadt (Jakominiplatz / Radetzkystraße). Schneller Zugang zu frischen CBD-Tropfen, Purize-Gläsern, Papers und modischen Lifestyle-Accessoires.'}
                </p>

                {/* Info Blocks */}
                <div className="flex flex-col gap-4 border-t border-b border-white/10 py-5 mb-6">
                  {/* Hours */}
                  <div>
                    <span className="text-xs font-bold text-[#DFCAAB] flex items-center gap-1.5 mb-1.5 font-heading">
                      <Clock className="w-3.5 h-3.5 text-[#C5A880]" />
                      ÖFFNUNGSZEITEN
                    </span>
                    <div className="text-xs sm:text-sm text-[#DFDAD0] flex flex-col gap-1">
                      <div className="flex justify-between">
                        <span>Wochentags:</span>
                        <strong className="text-white font-mono">{currentStore.hoursWeekday}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Wochenende:</span>
                        <strong className="text-white font-mono">{currentStore.hoursWeekend}</strong>
                      </div>
                    </div>
                  </div>

                  {/* Transit */}
                  <div>
                    <span className="text-xs font-bold text-[#DFCAAB] flex items-center gap-1.5 mb-1.5 font-heading">
                      <TrainTrack className="w-3.5 h-3.5 text-[#C5A880]" />
                      ÖFFENTLICHE ANBINDUNG (GKB / BIM)
                    </span>
                    <p className="text-xs text-[#8E9F94] leading-relaxed">
                      {currentStore.tramInfo}
                    </p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3">
                <a
                  href={currentStore.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-gold inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-bold cursor-pointer"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Google Maps Route</span>
                </a>

                <a
                  href={`tel:${currentStore.phone}`}
                  className="btn-outline-gold inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-bold cursor-pointer bg-white/5"
                >
                  <Phone className="w-3.5 h-3.5 text-[#C5A880]" />
                  <span>{currentStore.phoneDisplay}</span>
                </a>
              </div>
            </div>

            {/* Embedded Interactive Map */}
            <div className="lg:col-span-6 rounded-2xl overflow-hidden border border-white/10 min-h-[300px] lg:min-h-[380px] bg-black/60 relative">
              <iframe
                title={`Map of ${currentStore.name}`}
                src={currentStore.embedUrl}
                width="100%"
                height="100%"
                style={{ border: 0, minHeight: '300px', filter: 'invert(90%) hue-rotate(180deg) brightness(85%) contrast(110%)' }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full"
              />
              <div className="absolute bottom-3 left-3 bg-black/90 px-3 py-1.5 rounded-lg border border-white/10 text-[10px] text-[#DFDAD0]">
                {currentStore.address}, 8020 Graz
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
