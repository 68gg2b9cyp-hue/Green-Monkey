import React, { useState } from 'react';
import { X, ShieldCheck, Scale, FileText, CheckCircle2, Lock, Building, MapPin, Mail, Phone, Info } from 'lucide-react';
import { STORES } from '../data/storeData';

export type LegalModalTab = 'impressum' | 'privacy' | 'datenschutz' | 'cookies';

interface LegalModalProps {
  isOpen: boolean;
  initialTab?: LegalModalTab;
  onClose: () => void;
}

export const LegalModal: React.FC<LegalModalProps> = ({
  isOpen,
  initialTab = 'impressum',
  onClose,
}) => {
  const normalizeTab = (t?: string): 'impressum' | 'privacy' | 'cookies' => {
    if (t === 'datenschutz' || t === 'privacy') return 'privacy';
    if (t === 'cookies') return 'cookies';
    return 'impressum';
  };

  const [activeTab, setActiveTab] = useState<'impressum' | 'privacy' | 'cookies'>(normalizeTab(initialTab));
  const [cookieAnalytics, setCookieAnalytics] = useState(false);
  const [savedCookiesMessage, setSavedCookiesMessage] = useState(false);

  // Sync tab when opened with a specific tab
  React.useEffect(() => {
    setActiveTab(normalizeTab(initialTab));
  }, [initialTab]);

  if (!isOpen) return null;

  const handleSaveCookies = () => {
    localStorage.setItem('gm_cookie_analytics', cookieAnalytics ? 'true' : 'false');
    setSavedCookiesMessage(true);
    setTimeout(() => {
      setSavedCookiesMessage(false);
      onClose();
    }, 900);
  };

  const handleAcceptAllCookies = () => {
    setCookieAnalytics(true);
    localStorage.setItem('gm_cookie_analytics', 'true');
    setSavedCookiesMessage(true);
    setTimeout(() => {
      setSavedCookiesMessage(false);
      onClose();
    }, 900);
  };

  const handleAcceptOnlyNecessary = () => {
    setCookieAnalytics(false);
    localStorage.setItem('gm_cookie_analytics', 'false');
    setSavedCookiesMessage(true);
    setTimeout(() => {
      setSavedCookiesMessage(false);
      onClose();
    }, 900);
  };

  return (
    <div
      id="legal-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md transition-opacity duration-300 overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div 
        id="legal-modal-card" 
        className="w-full max-w-3xl bg-[#0F2218]/95 border border-[#C5A880]/30 rounded-3xl p-6 sm:p-8 text-left shadow-2xl relative max-h-[90vh] flex flex-col text-white"
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-2.5">
            <Scale className="w-5 h-5 text-[#C5A880]" />
            <h2 className="font-heading font-bold text-lg sm:text-xl text-[#F6F4EE]">
              Rechtliche Informationen &amp; Compliance [Österreich]
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-full text-white/60 hover:text-white bg-black/40 hover:bg-black/80 border border-white/10 transition-colors cursor-pointer"
            aria-label="Schließen"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-2 pt-4 pb-2 border-b border-white/10 shrink-0 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('impressum')}
            className={`px-4 py-2 rounded-full text-xs sm:text-sm font-heading font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'impressum'
                ? 'bg-[#C5A880] text-[#07150D] shadow-md'
                : 'text-[#DFDAD0] hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>Impressum (§ 5 ECG)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('privacy')}
            className={`px-4 py-2 rounded-full text-xs sm:text-sm font-heading font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'privacy'
                ? 'bg-[#C5A880] text-[#07150D] shadow-md'
                : 'text-[#DFDAD0] hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>Datenschutz / DSGVO</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('cookies')}
            className={`px-4 py-2 rounded-full text-xs sm:text-sm font-heading font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'cookies'
                ? 'bg-[#C5A880] text-[#07150D] shadow-md'
                : 'text-[#DFDAD0] hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Cookie-Einstellungen</span>
          </button>
        </div>

        {/* Scrollable Content Body in Subtle Muted Sage & Crisp Contrast */}
        <div className="overflow-y-auto py-5 pr-2 space-y-6 text-sm text-[#9EB0A4] leading-relaxed scrollbar-thin">
          
          {/* TAB 1: IMPRESSUM */}
          {activeTab === 'impressum' && (
            <div className="space-y-6">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#C5A880]">
                  Offenlegung gemäß § 5 ECG, § 25 Mediengesetz &amp; § 14 UGB
                </span>
                <h3 className="font-heading text-lg font-bold text-[#F6F4EE] mt-1">
                  Green Monkey Graz
                </h3>
                <p className="text-xs text-[#8E9F94] mt-0.5">
                  Fachhandel für Bio-CBD Nutzhanf, Rauchkultur &amp; Raucherbedarfsartikel
                </p>
              </div>

              {/* Company & Register Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white/[0.02] border border-white/5 rounded-xl p-4">
                <div>
                  <h4 className="text-xs font-bold text-[#DFDAD0] uppercase tracking-wider mb-2">
                    Unternehmensdaten
                  </h4>
                  <ul className="space-y-1.5 text-xs text-[#9EB0A4]">
                    <li><strong className="text-[#DFDAD0]">Medieninhaber &amp; Betreiber:</strong> Green Monkey Graz OG</li>
                    <li><strong className="text-[#DFDAD0]">Rechtsform:</strong> Offene Gesellschaft (OG)</li>
                    <li><strong className="text-[#DFDAD0]">UID-Nummer:</strong> ATU74829103</li>
                    <li><strong className="text-[#DFDAD0]">Firmenbuchnummer:</strong> FN 518429 p</li>
                    <li><strong className="text-[#DFDAD0]">Firmenbuchgericht:</strong> Landesgericht für ZRS Graz</li>
                    <li><strong className="text-[#DFDAD0]">Behörde gem. ECG:</strong> Magistrat der Stadt Graz</li>
                  </ul>
                </div>

                <div>
                  <h4 className="text-xs font-bold text-[#DFDAD0] uppercase tracking-wider mb-2">
                    Kammer &amp; Berufsrecht
                  </h4>
                  <ul className="space-y-1.5 text-xs text-[#9EB0A4]">
                    <li><strong className="text-[#DFDAD0]">Kammerzugehörigkeit:</strong> Wirtschaftskammer Steiermark (WKO)</li>
                    <li><strong className="text-[#DFDAD0]">Fachgruppe:</strong> Handel mit Mode- und Freizeitartikeln / Tabaktrafikanten-Bedarf</li>
                    <li><strong className="text-[#DFDAD0]">Anwendbare Rechtsvorschriften:</strong> Gewerbeordnung (GewO), E-Commerce-Gesetz (ECG), Suchtmittelgesetz (SMG)</li>
                    <li><strong className="text-[#DFDAD0]">Aufsichtsbehörde:</strong> Gewerbebehörde Magistrat Graz</li>
                  </ul>
                </div>
              </div>

              {/* Physical Store Locations in Graz */}
              <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4">
                <h4 className="text-xs font-bold text-[#DFDAD0] uppercase tracking-wider mb-3">
                  Standorte &amp; Kontaktaufnahme
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {STORES.map((store) => (
                    <div key={store.id} className="p-3 rounded-lg bg-black/30 border border-white/5">
                      <div className="text-xs font-bold text-[#DFCAAB] mb-1">{store.name}</div>
                      <div className="text-xs text-[#DFDAD0] flex items-center gap-1.5 mb-1">
                        <MapPin className="w-3.5 h-3.5 text-[#C5A880] shrink-0" />
                        <span>{store.address}, {store.postalCode} {store.city}</span>
                      </div>
                      <div className="text-xs text-[#9EB0A4] flex items-center gap-1.5 mb-1">
                        <Phone className="w-3.5 h-3.5 text-[#8E9F94] shrink-0" />
                        <a href={`tel:${store.phone}`} className="hover:underline">{store.phoneDisplay}</a>
                      </div>
                      <div className="text-xs text-[#9EB0A4] flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-[#8E9F94] shrink-0" />
                        <a href={`mailto:${store.email}`} className="hover:underline">{store.email}</a>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Important Disclaimers as required */}
              <div className="space-y-3 pt-2">
                <div className="p-3.5 rounded-xl bg-[#C5A880]/5 border border-[#C5A880]/20">
                  <h5 className="text-xs font-bold text-[#DFCAAB] mb-1">
                    Ausschließlich stationärer Verkauf (Kein Online-Shop)
                  </h5>
                  <p className="text-xs text-[#9EB0A4] leading-relaxed">
                    Diese Website dient ausschließlich Informationszwecken und stellt keinen Online-Shop dar. Der Verkauf aller Produkte erfolgt ausschließlich vor Ort in unseren Filialen in Graz an Personen ab 18 Jahren.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-white/[0.02] border border-white/5">
                  <h5 className="text-xs font-bold text-[#DFDAD0] mb-1">
                    Marken- &amp; Namensrechte
                  </h5>
                  <p className="text-xs text-[#8E9F94] leading-relaxed">
                    Alle auf dieser Website genannten Marken, Produktnamen und Logos (wie z. B. RAW, ELFBAR, Purize, Cannaline u. a.) sind Eigentum der jeweiligen Rechteinhaber und werden ausschließlich zur eindeutigen Identifizierung und Beschreibung des Sortiments verwendet.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-emerald-950/20 border border-emerald-500/20">
                  <h5 className="text-xs font-bold text-emerald-300 mb-1">
                    CBD-Konformität &amp; Gesundheitshinweis
                  </h5>
                  <p className="text-xs text-[#9EB0A4] leading-relaxed">
                    Unsere CBD-Produkte und Pflanzenauszüge dienen nicht der Diagnose, Behandlung, Heilung oder Vorbeugung von Krankheiten. Alle Hanfprodukte entsprechen den österreichischen gesetzlichen Bestimmungen mit einem THC-Gehalt von unter 0,3%.
                  </p>
                </div>
              </div>

              {/* Dispute Resolution */}
              <div className="text-xs text-[#8E9F94] pt-2">
                <p>
                  <strong>Online-Streitbeilegung:</strong> Verbraucher haben die Möglichkeit, Beschwerden an die Online-Streitbeilegungsplattform der EU zu richten: <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noreferrer" className="text-[#C5A880] hover:underline">https://ec.europa.eu/consumers/odr</a>. Sie können eventuelle Beschwerden auch an die oben angegebene E-Mail-Adresse richten.
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: DATENSCHUTZ / PRIVACY */}
          {activeTab === 'privacy' && (
            <div className="space-y-5">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#C5A880]">
                  Datenschutzerklärung nach der EU-Datenschutz-Grundverordnung (DSGVO)
                </span>
                <h3 className="font-heading text-lg font-bold text-[#F6F4EE] mt-1">
                  Schutz Ihrer Privatsphäre bei Green Monkey Graz
                </h3>
                <p className="text-xs text-[#8E9F94] mt-0.5">
                  Stand: {new Date().getFullYear()} • Gültig für www.greenmonkey-graz.at
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-3">
                <h4 className="text-xs font-bold text-[#DFDAD0] uppercase tracking-wider">
                  1. Grundsatz: Reine Informationsseite ohne Online-Shop
                </h4>
                <p className="text-xs text-[#9EB0A4] leading-relaxed">
                  Wir freuen uns über Ihren Besuch auf unserer Informationswebsite. Der Schutz Ihrer persönlichen Daten ist uns ein besonderes Anliegen. Wir betreiben über dieses Webportal <strong>keinen Webshop</strong>, wickeln keine Online-Zahlungen ab und erstellen keine Nutzerprofile zu Werbezwecken.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-3">
                <h4 className="text-xs font-bold text-[#DFDAD0] uppercase tracking-wider">
                  2. Verantwortlicher für die Datenverarbeitung
                </h4>
                <p className="text-xs text-[#9EB0A4]">
                  Green Monkey Graz OG<br />
                  Annenstraße 68, 8020 Graz, Österreich<br />
                  E-Mail: <a href="mailto:info@greenmonkey-graz.at" className="text-[#DFCAAB] hover:underline">info@greenmonkey-graz.at</a><br />
                  Telefon: +43 316 584 022
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-3">
                <h4 className="text-xs font-bold text-[#DFDAD0] uppercase tracking-wider">
                  3. Lokale Speicherung im Browser (LocalStorage)
                </h4>
                <p className="text-xs text-[#9EB0A4] leading-relaxed">
                  Um Ihnen einen reibungslosen Besuch zu ermöglichen, speichern wir rein funktionale Werte in Ihrem lokalen Browserspeicher (LocalStorage):
                </p>
                <ul className="list-disc pl-5 space-y-1 text-xs text-[#9EB0A4]">
                  <li><strong className="text-[#DFDAD0]">gm_age_verified:</strong> Speichert Ihre Bestätigung, dass Sie über 18 Jahre alt sind, damit die gesetzliche Altersüberprüfung nicht bei jedem Seitenwechsel erneut erscheint.</li>
                  <li><strong className="text-[#DFDAD0]">gm_cookie_analytics:</strong> Speichert Ihre Auswahl bezüglich optionaler Komfort-Einstellungen.</li>
                </ul>
                <p className="text-xs text-[#8E9F94]">
                  Diese Daten verbleiben auf Ihrem Endgerät und werden nicht an externe Server übertragen oder zu Werbezwecken verwertet.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-3">
                <h4 className="text-xs font-bold text-[#DFDAD0] uppercase tracking-wider">
                  4. Server-Logdateien
                </h4>
                <p className="text-xs text-[#9EB0A4] leading-relaxed">
                  Beim Aufruf unserer Website erhebt der Hosting-Provider aus technischen Gründen automatisch Daten, die Ihr Browser übermittelt (IP-Adresse, Datum und Uhrzeit der Serveranfrage, Browsertyp und Betriebssystem). Dies erfolgt auf Grundlage unseres berechtigten Interesses an der Systemsicherheit gem. Art. 6 Abs. 1 lit. f DSGVO.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-3">
                <h4 className="text-xs font-bold text-[#DFDAD0] uppercase tracking-wider">
                  5. Ihre Betroffenenrechte nach DSGVO
                </h4>
                <p className="text-xs text-[#9EB0A4] leading-relaxed">
                  Ihnen stehen grundsätzlich die Rechte auf Auskunft, Berichtigung, Löschung, Einschränkung, Datenübertragbarkeit und Widerspruch zu (Art. 15–21 DSGVO). Wenn Sie glauben, dass die Verarbeitung Ihrer Daten gegen das Datenschutzrecht verstößt, können Sie sich an die österreichische Datenschutzbehörde (Barichgasse 40-42, 1030 Wien, <a href="https://www.dsb.gv.at" target="_blank" rel="noreferrer" className="text-[#DFCAAB] hover:underline">www.dsb.gv.at</a>) wenden.
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: COOKIE-EINSTELLUNGEN */}
          {activeTab === 'cookies' && (
            <div className="space-y-5">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#C5A880]">
                  Privatsphäre &amp; Datensicherheit
                </span>
                <h3 className="font-heading text-lg font-bold text-[#F6F4EE] mt-1">
                  Cookie- &amp; Speicher-Einstellungen
                </h3>
                <p className="text-xs text-[#8E9F94] mt-0.5">
                  Verwalten Sie die im Browser hinterlegten Präferenzen für Green Monkey Graz.
                </p>
              </div>

              {savedCookiesMessage && (
                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-center gap-2 text-xs text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Ihre Einstellungen wurden erfolgreich auf Ihrem Gerät gespeichert.</span>
                </div>
              )}

              {/* Essential Cookies */}
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-sm text-[#F6F4EE]">Notwendige Funktionen &amp; Jugendschutz</span>
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#C5A880]/20 text-[#DFCAAB]">
                      Immer Aktiv
                    </span>
                  </div>
                  <p className="text-xs text-[#9EB0A4] leading-relaxed">
                    Diese Werte sind technisch zwingend erforderlich, um gesetzliche Vorschriften (18+ Altersverifikation) zu gewährleisten und die gewählte Filialansicht während Ihrer Sitzung zu merken.
                  </p>
                </div>
                <div className="pt-1">
                  <div className="w-10 h-5 bg-[#C5A880]/40 rounded-full flex items-center p-0.5 opacity-80 cursor-not-allowed">
                    <div className="w-4 h-4 bg-[#DFCAAB] rounded-full translate-x-5" />
                  </div>
                </div>
              </div>

              {/* Optional Analytics Cookies */}
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-sm text-[#F6F4EE]">Anonyme Leistungs- &amp; Darstellungsoptimierung</span>
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-white/10 text-[#8E9F94]">
                      Optional
                    </span>
                  </div>
                  <p className="text-xs text-[#9EB0A4] leading-relaxed">
                    Ermöglicht uns zu verstehen, welche Katalogbereiche (z. B. RAW Sortiment, Filtergläser, Bio-CBD Tees) am stärksten nachgefragt werden, um das Sortiment in den Grazer Filialen optimal abzustimmen.
                  </p>
                </div>
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => setCookieAnalytics(!cookieAnalytics)}
                    className={`w-11 h-6 rounded-full transition-colors p-0.5 cursor-pointer relative ${
                      cookieAnalytics ? 'bg-emerald-600' : 'bg-white/10'
                    }`}
                    aria-label="Analyse aktivieren"
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white transition-transform ${
                        cookieAnalytics ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Reset Age Verification */}
              <div className="p-4 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-[#DFDAD0]">Altersüberprüfung (18+) zurücksetzen</div>
                  <div className="text-[11px] text-[#8E9F94]">Setzt den Status zurück, sodass beim nächsten Neuladen erneut das 18+ Abfragefenster erscheint.</div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    localStorage.removeItem('gm_age_verified');
                    alert('Altersstatus zurückgesetzt. Beim nächsten Neuladen wird die Altersprüfung erneut angezeigt.');
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-[#DFCAAB] bg-white/5 hover:bg-white/10 border border-white/10 cursor-pointer whitespace-nowrap"
                >
                  Zurücksetzen
                </button>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 flex flex-col sm:flex-row gap-2.5 justify-end">
                <button
                  type="button"
                  onClick={handleAcceptOnlyNecessary}
                  className="px-4 py-2.5 rounded-xl text-xs font-medium text-[#9EB0A4] hover:text-[#DFDAD0] bg-white/5 hover:bg-white/10 border border-white/10 cursor-pointer"
                >
                  Nur notwendige akzeptieren
                </button>
                <button
                  type="button"
                  onClick={handleSaveCookies}
                  className="px-4 py-2.5 rounded-xl text-xs font-semibold text-[#07150D] bg-[#DFCAAB] hover:bg-[#F6F4EE] cursor-pointer"
                >
                  Einstellungen speichern
                </button>
                <button
                  type="button"
                  onClick={handleAcceptAllCookies}
                  className="px-4 py-2.5 rounded-xl text-xs font-semibold text-[#07150D] bg-gradient-to-r from-[#DFCAAB] to-[#C5A880] hover:brightness-110 cursor-pointer"
                >
                  Alle akzeptieren
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Footer Note */}
        <div className="pt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-[#718578] shrink-0">
          <span>Green Monkey Graz • Rechtsabteilung &amp; Jugendschutz</span>
          <button
            type="button"
            onClick={onClose}
            className="text-[#9EB0A4] hover:text-[#F6F4EE] hover:underline cursor-pointer"
          >
            Schließen
          </button>
        </div>

      </div>
    </div>
  );
};
