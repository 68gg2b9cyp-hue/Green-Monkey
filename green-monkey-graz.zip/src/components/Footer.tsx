import React from 'react';
import { STORES } from '../data/storeData';
import { Shield, MapPin, Phone, Scale, Lock, ShieldCheck, AlertCircle } from 'lucide-react';
import { GreenMonkeyLogo } from './GreenMonkeyLogo';
import { AppView, ProductCategory } from '../types';
import { LegalModalTab } from './LegalModal';

interface FooterProps {
  onNavigate?: (view: AppView) => void;
  onSelectCategory?: (category: ProductCategory) => void;
  onOpenLegal?: (tab: LegalModalTab) => void;
  onOpenAgeGate?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ 
  onNavigate, 
  onSelectCategory,
  onOpenLegal,
  onOpenAgeGate
}) => {
  const handleNavToCatalog = (cat: ProductCategory = 'all') => {
    if (onSelectCategory) onSelectCategory(cat);
    if (onNavigate) onNavigate('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavToSection = (sectionId: string) => {
    if (onNavigate) onNavigate('home');
    setTimeout(() => {
      const el = document.getElementById(sectionId);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 50);
  };

  const handleLegalClick = (tab: LegalModalTab) => {
    if (onOpenLegal) {
      onOpenLegal(tab);
    }
  };

  return (
    <footer className="bg-[#0A160F]/95 backdrop-blur-md border-t border-white/10 pt-16 pb-12 shadow-2xl" id="contact">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 mb-12">
          
          {/* Brand Info */}
          <div className="lg:col-span-4 flex flex-col items-start">
            <div className="flex items-center gap-3 mb-4">
              <GreenMonkeyLogo size="md" showRing={true} />
              <div className="flex flex-col">
                <span className="font-heading font-bold text-lg text-[#F6F4EE]">
                  GREEN MONKEY
                </span>
                <span className="text-[10px] tracking-widest text-[#C5A880] font-semibold">
                  CANNABIS SHOP • GRAZ
                </span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#9EB0A4] leading-relaxed mb-5 max-w-sm">
              Offizieller Fachhandel für zertifizierten Bio-CBD Nutzhanf (&lt;0,3% THC) und originale Rauchkultur führender Weltmarken an zwei zentralen Standorten in Graz.
            </p>

            <div className="inline-flex items-center gap-1.5 text-[11px] font-extrabold tracking-wider text-red-400 bg-red-950/40 border border-red-500/30 px-3 py-1 rounded">
              <Shield className="w-3.5 h-3.5" />
              18+ NUR FÜR ERWACHSENE • AUSWEISPFLICHT
            </div>
          </div>

          {/* Stores */}
          <div className="lg:col-span-3">
            <h4 className="font-heading font-bold text-sm text-[#F6F4EE] uppercase tracking-wider mb-4">
              Filialen in Graz
            </h4>
            <ul className="flex flex-col gap-3 text-xs sm:text-sm text-[#9EB0A4]">
              {STORES.map((s) => (
                <li key={s.id} className="flex flex-col">
                  <strong className="text-[#DFDAD0]">{s.name}</strong>
                  <span>{s.address}, {s.postalCode} {s.city}</span>
                  <a href={`tel:${s.phone}`} className="text-[11px] text-[#C5A880] hover:underline mt-0.5">
                    {s.phoneDisplay}
                  </a>
                </li>
              ))}
              <li className="pt-2">
                <button
                  type="button"
                  onClick={() => handleNavToSection('stores')}
                  className="text-xs font-semibold text-[#DFCAAB] hover:underline cursor-pointer"
                >
                  Öffnungszeiten &amp; Anfahrt ansehen ↗
                </button>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div className="lg:col-span-3">
            <h4 className="font-heading font-bold text-sm text-[#F6F4EE] uppercase tracking-wider mb-4">
              Sortiment im Katalog
            </h4>
            <ul className="flex flex-col gap-2 text-xs sm:text-sm text-[#8E9F94]">
              <li>
                <button
                  type="button"
                  onClick={() => handleNavToCatalog('raw')}
                  className="hover:text-[#DFCAAB] transition-colors cursor-pointer text-left"
                >
                  RAW Sortiment (Trays &amp; Boxen)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleNavToCatalog('filters')}
                  className="hover:text-[#DFCAAB] transition-colors cursor-pointer text-left"
                >
                  Purize &amp; ActiTube Aktivkohlefilter
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleNavToCatalog('headshop')}
                  className="hover:text-[#DFCAAB] transition-colors cursor-pointer text-left"
                >
                  Borosilikat Glasbongs &amp; Rigs
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleNavToCatalog('grinder')}
                  className="hover:text-[#DFCAAB] transition-colors cursor-pointer text-left"
                >
                  CNC-Aluminium Metall-Grinder
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleNavToCatalog('cbd')}
                  className="hover:text-[#DFCAAB] transition-colors cursor-pointer text-left"
                >
                  Bio CBD-Öle &amp; Aromablüten
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleNavToCatalog('tea')}
                  className="hover:text-[#DFCAAB] transition-colors cursor-pointer text-left flex items-center gap-1.5"
                >
                  <span>Cannaline Bio CBD Kräutertees</span>
                  <span className="text-[10px] text-[#C5A880] border border-[#C5A880]/30 px-1 py-0.2 rounded">Bio</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Legal Structure Links (Austrian Compliance) */}
          <div className="lg:col-span-2">
            <h4 className="font-heading font-bold text-sm text-[#F6F4EE] uppercase tracking-wider mb-4">
              Rechtliches &amp; Pflichtangaben
            </h4>
            <ul className="flex flex-col gap-2.5 text-xs sm:text-sm text-[#8E9F94]">
              <li>
                <button
                  id="footer-link-impressum"
                  type="button"
                  onClick={() => handleLegalClick('impressum')}
                  className="text-left text-[#DFDAD0] hover:text-[#DFCAAB] transition-colors cursor-pointer flex items-center gap-1.5 group"
                >
                  <Scale className="w-3.5 h-3.5 text-[#C5A880] group-hover:translate-x-0.5 transition-transform" />
                  <span>Impressum</span>
                </button>
              </li>
              <li>
                <button
                  id="footer-link-privacy"
                  type="button"
                  onClick={() => handleLegalClick('privacy')}
                  className="text-left text-[#DFDAD0] hover:text-[#DFCAAB] transition-colors cursor-pointer flex items-center gap-1.5 group"
                >
                  <Lock className="w-3.5 h-3.5 text-[#C5A880] group-hover:translate-x-0.5 transition-transform" />
                  <span>Datenschutz / Privacy Policy</span>
                </button>
              </li>
              <li>
                <button
                  id="footer-link-cookies"
                  type="button"
                  onClick={() => handleLegalClick('cookies')}
                  className="text-left text-[#DFDAD0] hover:text-[#DFCAAB] transition-colors cursor-pointer flex items-center gap-1.5 group"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-[#C5A880] group-hover:translate-x-0.5 transition-transform" />
                  <span>Cookie-Einstellungen</span>
                </button>
              </li>
              <li className="pt-1">
                <button
                  type="button"
                  onClick={() => {
                    if (onOpenAgeGate) onOpenAgeGate();
                  }}
                  className="text-left text-[11px] text-[#718578] hover:text-[#9EB0A4] transition-colors cursor-pointer"
                >
                  Altersprüfung (18+) öffnen
                </button>
              </li>
            </ul>
          </div>

        </div>

        {/* 2. FOOTER LEGAL DISCLAIMERS (Subtle Muted Gray/Sage Tone) */}
        <div className="border-t border-white/10 pt-8 pb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            
            {/* Disclaimer 1: No E-Commerce */}
            <div className="p-4 rounded-xl bg-black/25 border border-white/5 flex flex-col justify-between">
              <div>
                <div className="text-[11px] font-bold uppercase tracking-wider text-[#C5A880] mb-1.5 flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>Kein Online-Shop • Nur vor Ort</span>
                </div>
                <p className="text-xs text-[#8E9F94] leading-relaxed">
                  Diese Website dient ausschließlich Informationszwecken und stellt keinen Online-Shop dar. Der Verkauf aller Produkte erfolgt ausschließlich vor Ort in unseren Filialen in Graz an Personen ab 18 Jahren.
                </p>
              </div>
            </div>

            {/* Disclaimer 2: Trademark & Brand Rights */}
            <div className="p-4 rounded-xl bg-black/25 border border-white/5 flex flex-col justify-between">
              <div>
                <div className="text-[11px] font-bold uppercase tracking-wider text-[#9EB0A4] mb-1.5">
                  Marken- &amp; Urheberrechte
                </div>
                <p className="text-xs text-[#8E9F94] leading-relaxed">
                  Alle auf dieser Website genannten Marken, Produktnamen und Logos (wie z. B. RAW, ELFBAR, Purize, Cannaline u. a.) sind Eigentum der jeweiligen Rechteinhaber und werden ausschließlich zur eindeutigen Identifizierung und Beschreibung des Sortiments verwendet.
                </p>
              </div>
            </div>

            {/* Disclaimer 3: CBD & Compliance (No Medical Claims) */}
            <div className="p-4 rounded-xl bg-black/25 border border-white/5 flex flex-col justify-between">
              <div>
                <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-400/90 mb-1.5">
                  CBD &amp; Compliance (Keine Heilversprechen)
                </div>
                <p className="text-xs text-[#8E9F94] leading-relaxed">
                  Unsere CBD-Produkte und Pflanzenauszüge dienen nicht der Diagnose, Behandlung, Heilung oder Vorbeugung von Krankheiten. Alle Hanfprodukte entsprechen den österreichischen gesetzlichen Bestimmungen mit einem THC-Gehalt von unter 0,3%.
                </p>
              </div>
            </div>

          </div>
        </div>

        {/* Obligatory Austrian Business Footer Bottom Bar */}
        <div className="border-t border-white/5 pt-6 flex flex-col sm:flex-row items-center justify-between text-center sm:text-left gap-4">
          <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4 text-xs text-[#718578]">
            <span>© {new Date().getFullYear()} Green Monkey Graz OG. Alle Rechte vorbehalten.</span>
            <span className="hidden sm:inline text-white/10">•</span>
            <span>WKO Steiermark (Fachgruppe Handel)</span>
            <span className="hidden sm:inline text-white/10">•</span>
            <span>UID: ATU74829103</span>
          </div>

          <div className="flex items-center gap-4 text-xs text-[#8E9F94]">
            <button
              type="button"
              onClick={() => handleLegalClick('impressum')}
              className="hover:text-[#DFCAAB] transition-colors cursor-pointer"
            >
              Impressum
            </button>
            <span className="text-white/10">|</span>
            <button
              type="button"
              onClick={() => handleLegalClick('privacy')}
              className="hover:text-[#DFCAAB] transition-colors cursor-pointer"
            >
              Datenschutz
            </button>
            <span className="text-white/10">|</span>
            <button
              type="button"
              onClick={() => handleLegalClick('cookies')}
              className="hover:text-[#DFCAAB] transition-colors cursor-pointer"
            >
              Cookie-Einstellungen
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};

