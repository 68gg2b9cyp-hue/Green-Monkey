import React, { useState } from 'react';
import { GreenMonkeyLogo } from './GreenMonkeyLogo';
import { ShieldCheck, X, ChevronRight, Store } from 'lucide-react';

export const CornerLogoBadge: React.FC = () => {
  const [minimized, setMinimized] = useState(false);

  const handleScrollToStores = () => {
    const el = document.getElementById('stores');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  if (minimized) {
    return (
      <button
        type="button"
        onClick={() => setMinimized(false)}
        className="fixed bottom-4 left-4 z-40 flex items-center gap-2 p-1.5 pr-3 bg-[#0B1A12]/95 hover:bg-[#12281D] border border-[#C5A880]/50 rounded-full shadow-2xl shadow-black/80 backdrop-blur-md cursor-pointer transition-all hover:scale-105 group"
        title="Offizielles Green Monkey Logo öffnen"
      >
        <GreenMonkeyLogo size="xs" showRing={true} />
        <span className="text-[11px] font-heading font-extrabold text-[#DFCAAB] group-hover:text-[#F6F4EE]">
          GREEN MONKEY
        </span>
      </button>
    );
  }

  return (
    <aside
      aria-label="Offizieller Green Monkey Store Graz"
      className="fixed bottom-4 left-4 z-40 max-w-[280px] sm:max-w-xs bg-gradient-to-br from-[#0D1E15]/95 via-[#0A1810]/95 to-[#06100B]/95 border border-[#C5A880]/40 rounded-2xl p-3.5 shadow-2xl shadow-black/90 backdrop-blur-md transition-all animate-fadeIn"
    >
      <div className="flex items-start justify-between gap-3 mb-2">
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <GreenMonkeyLogo size="md" showRing={true} />
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#0A1810] shadow-[0_0_8px_#34D399]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-heading font-black text-xs text-[#F6F4EE] tracking-wide leading-tight">
                GREEN MONKEY
              </span>
              <span className="text-[9px] font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-500/30 px-1.5 py-0.2 rounded">
                OFFIZIELL
              </span>
            </div>
            <span className="text-[10px] text-[#C5A880] font-semibold tracking-wider block">
              CANNABIS SHOP GRAZ
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setMinimized(true)}
          className="text-[#8E9F94] hover:text-[#F6F4EE] p-1 -mr-1 -mt-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
          title="Minimieren"
          aria-label="Minimieren"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      <p className="text-[11px] text-[#9EB0A4] leading-snug mb-2.5">
        Original-Fachgeschäft in Graz: Annenstraße 68 &amp; Radetzkystraße 13.
      </p>

      <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/10">
        <button
          type="button"
          onClick={handleScrollToStores}
          className="inline-flex items-center gap-1 text-[11px] font-bold text-[#DFCAAB] hover:text-[#F6F4EE] transition-colors cursor-pointer"
        >
          <Store className="w-3 h-3 text-[#C5A880]" />
          <span>Filialen anzeigen</span>
          <ChevronRight className="w-3 h-3" />
        </button>
        <span className="text-[10px] text-[#7A8C80]">18+</span>
      </div>
    </aside>
  );
};
