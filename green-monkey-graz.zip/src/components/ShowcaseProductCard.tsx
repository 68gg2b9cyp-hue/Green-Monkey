import React from 'react';
import { ShowcaseProduct } from '../data/luxuryShowcaseData';
import { 
  Sparkles, 
  Leaf, 
  Droplet, 
  Wind, 
  Zap, 
  Box, 
  Gem, 
  Moon, 
  Clock, 
  Feather, 
  ShieldCheck, 
  ChevronRight,
  Store
} from 'lucide-react';

interface ShowcaseProductCardProps {
  product: ShowcaseProduct;
  onOpenDetails: (product: ShowcaseProduct) => void;
  onCheckAvailability?: (product: ShowcaseProduct) => void;
}

export const ShowcaseProductCard: React.FC<ShowcaseProductCardProps> = ({
  product,
  onOpenDetails,
  onCheckAvailability,
}) => {
  const getBadgeStyle = () => {
    switch (product.badgeType) {
      case 'gold':
        return 'text-[#DFCAAB] bg-[#C5A880]/20 border-[#C5A880]/50 shadow-[0_0_10px_rgba(197,168,128,0.2)]';
      case 'sage':
        return 'text-[#B8C9BD] bg-[#8E9F94]/20 border-[#8E9F94]/50';
      case 'emerald':
        return 'text-emerald-300 bg-emerald-950/80 border-emerald-500/50 shadow-[0_0_10px_rgba(16,185,129,0.2)]';
      case 'amber':
        return 'text-amber-300 bg-amber-950/80 border-amber-500/50 shadow-[0_0_10px_rgba(245,158,11,0.2)]';
      default:
        return 'text-[#DFDAD0] bg-white/10 border-white/20';
    }
  };

  const renderIcon = () => {
    const iconClass = "w-9 h-9 text-[#C5A880] group-hover:text-[#F5F5F0] transition-colors drop-shadow-[0_0_14px_rgba(197,168,128,0.4)]";
    switch (product.iconName) {
      case 'leaf':
        return <Leaf className={iconClass} />;
      case 'droplet':
        return <Droplet className={iconClass} />;
      case 'wind':
        return <Wind className={iconClass} />;
      case 'zap':
        return <Zap className={iconClass} />;
      case 'box':
        return <Box className={iconClass} />;
      case 'gem':
        return <Gem className={iconClass} />;
      case 'moon':
        return <Moon className={iconClass} />;
      case 'clock':
        return <Clock className={iconClass} />;
      case 'feather':
        return <Feather className={iconClass} />;
      case 'shield':
        return <ShieldCheck className={iconClass} />;
      case 'sparkle':
      default:
        return <Sparkles className={iconClass} />;
    }
  };

  const [imageError, setImageError] = React.useState(false);

  const handleAvailabilityClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onCheckAvailability) {
      onCheckAvailability(product);
    } else {
      onOpenDetails(product);
    }
  };

  return (
    <article
      onClick={() => onOpenDetails(product)}
      className="group relative flex flex-col justify-between bg-gradient-to-b from-[#112419]/90 via-[#0D1F15]/90 to-[#0A1911]/90 rounded-2xl border border-emerald-800/40 hover:border-[#C5A880]/60 p-5 sm:p-6 transition-all duration-300 hover:shadow-2xl hover:shadow-emerald-950/70 hover:-translate-y-1 cursor-pointer overflow-hidden"
    >
      {/* Decorative Corner Glow */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 group-hover:bg-[#C5A880]/10 rounded-full blur-2xl transition-all pointer-events-none" />

      <div>
        {/* Real Product Image Showcase or Sleek Luminous Showcase */}
        <div
          className={`relative w-full aspect-[16/11] rounded-xl bg-gradient-to-br ${product.gradient} border border-emerald-800/40 group-hover:border-[#C5A880]/50 overflow-hidden mb-5 transition-all shadow-inner`}
        >
          {product.imageUrl && !imageError ? (
            <div className="w-full h-full bg-white flex items-center justify-center p-3 relative overflow-hidden">
              <img
                src={product.imageUrl}
                alt={product.name}
                referrerPolicy="no-referrer"
                loading="lazy"
                onError={() => setImageError(true)}
                className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500 ease-out drop-shadow-[0_4px_12px_rgba(0,0,0,0.3)]"
              />
            </div>
          ) : (
            <div className="w-full h-full flex items-center justify-center relative">
              {/* Radial Luminous Aura */}
              <div className="absolute inset-0 bg-radial from-emerald-500/20 via-transparent to-black/70 pointer-events-none" />
              <div className="absolute inset-0 opacity-[0.08] pointer-events-none bg-[radial-gradient(#C5A880_1px,transparent_1px)] [background-size:16px_16px]" />

              {/* Icon Center Stage */}
              <div className="relative z-10 w-16 h-16 rounded-2xl bg-black/60 backdrop-blur-md border border-[#C5A880]/30 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-500">
                {renderIcon()}
              </div>

              {/* Bottom Glow Bar */}
              <div className="absolute bottom-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-[#C5A880]/50 to-transparent" />
            </div>
          )}

          {/* Top-Right In-Store Micro Tag */}
          <div className="absolute top-2.5 right-2.5 z-10 flex items-center gap-1.5 text-[10px] font-bold text-[#F6F4EE] bg-black/85 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/15 shadow-md">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_6px_#34D399]" />
            <span>In Store Graz</span>
          </div>

          {/* Category Watermark */}
          <div className="absolute bottom-2.5 left-3 z-10 text-[9px] uppercase tracking-wider text-emerald-200/80 bg-black/70 backdrop-blur-md px-2 py-0.5 rounded-md font-heading font-extrabold select-none border border-white/10">
            {product.group}
          </div>
        </div>

        {/* Badge & Stock Indicator */}
        <div className="flex items-center justify-between gap-2 mb-2.5">
          <span
            className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full border font-heading ${getBadgeStyle()}`}
          >
            {product.badge}
          </span>
          <span className="text-[11px] text-[#8E9F94] font-medium flex items-center gap-1">
            <Store className="w-3 h-3 text-[#C5A880]" />
            <span>2x Filialen</span>
          </span>
        </div>

        {/* Product Name */}
        <h4 className="font-heading font-bold text-base sm:text-lg text-[#F5F5F0] group-hover:text-[#DFCAAB] transition-colors leading-snug mb-1.5 line-clamp-2">
          {product.name}
        </h4>

        {/* Subtitle */}
        <p className="text-xs text-[#9EB0A4] line-clamp-2 leading-relaxed mb-4">
          {product.subtitle}
        </p>
      </div>

      {/* Action CTA: 'Verfügbarkeit im Store prüfen / Check Availability' */}
      <div className="pt-3 border-t border-emerald-900/40 flex flex-col gap-2">
        <button
          type="button"
          onClick={handleAvailabilityClick}
          className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold font-heading text-[#07150D] bg-gradient-to-r from-[#DFCAAB] to-[#C5A880] hover:from-[#FFF2DE] hover:to-[#DFCAAB] shadow-md shadow-[#C5A880]/20 hover:shadow-lg hover:shadow-[#C5A880]/30 transition-all cursor-pointer group/cta"
        >
          <Store className="w-3.5 h-3.5" />
          <span>Verfügbarkeit im Store prüfen</span>
        </button>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onOpenDetails(product);
          }}
          className="w-full inline-flex items-center justify-center gap-1.5 py-1.5 text-[11px] font-semibold text-[#8E9F94] hover:text-[#DFCAAB] transition-colors"
        >
          <span>Produktdetails &amp; Botanik</span>
          <ChevronRight className="w-3 h-3 text-[#C5A880]" />
        </button>
      </div>
    </article>
  );
};
