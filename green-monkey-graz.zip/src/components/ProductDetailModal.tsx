import React from 'react';
import { ShowcaseProduct } from '../data/luxuryShowcaseData';
import { STORES } from '../data/storeData';
import { X, CheckCircle2, MapPin, Phone, ShieldCheck, Clock, Store, ArrowUpRight } from 'lucide-react';

interface ProductDetailModalProps {
  product: ShowcaseProduct | null;
  onClose: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
}) => {
  if (!product) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl bg-gradient-to-br from-[#10241A] via-[#0E1F16] to-[#08150E] border border-emerald-800/60 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/90 text-[#F5F5F0] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Ambient Top Glow */}
        <div className="absolute top-0 right-1/4 w-72 h-32 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-[#9EB0A4] hover:text-[#F5F5F0] bg-white/5 hover:bg-white/10 border border-white/10 transition-colors cursor-pointer"
          aria-label="Schließen"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Category & Badge */}
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <span className="text-[11px] font-bold tracking-widest uppercase text-[#C5A880] bg-[#C5A880]/15 border border-[#C5A880]/30 px-3 py-1 rounded-full font-heading">
            {product.group}
          </span>
          <span className="text-[11px] font-semibold text-emerald-300 bg-emerald-950/60 border border-emerald-700/40 px-3 py-1 rounded-full">
            {product.badge}
          </span>
          <span className="text-[11px] font-semibold text-[#9EB0A4] bg-white/5 px-2.5 py-1 rounded-full border border-white/10">
            Nur im Fachhandel vor Ort
          </span>
        </div>

        {/* Product Image Preview (when available) */}
        {product.imageUrl && (
          <div className="relative w-full h-56 sm:h-64 rounded-2xl overflow-hidden mb-4 border border-emerald-800/50 bg-white p-3 flex items-center justify-center shadow-inner">
            <img
              src={product.imageUrl}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain"
            />
          </div>
        )}

        {/* Title & Subtitle */}
        <h3 className="font-heading text-xl sm:text-2xl font-bold text-[#F5F5F0] mb-1.5 leading-snug">
          {product.name}
        </h3>
        <p className="text-xs sm:text-sm text-[#C5A880] font-medium mb-4">
          {product.subtitle}
        </p>

        {/* Details text */}
        <div className="bg-[#08150E]/80 border border-emerald-900/50 rounded-2xl p-4 mb-6 text-xs sm:text-sm text-[#DFDAD0] leading-relaxed">
          {product.details}
        </div>

        {/* In-Store Availability in Graz */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-[#9EB0A4] font-heading flex items-center gap-1.5">
              <Store className="w-3.5 h-3.5 text-[#C5A880]" />
              Verfügbarkeit in Graz
            </span>
            <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              In beiden Filialen vorrätig
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {STORES.map((s) => (
              <div
                key={s.id}
                className="p-3.5 rounded-2xl bg-white/5 border border-emerald-800/40 hover:border-emerald-700/60 transition-colors"
              >
                <div className="flex items-start justify-between gap-1 mb-1">
                  <strong className="text-xs font-bold text-[#F5F5F0] block">
                    {s.name}
                  </strong>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 mt-1 shrink-0 shadow-[0_0_6px_#34D399]" />
                </div>
                <div className="text-[11px] text-[#9EB0A4] mb-2">
                  {s.address}, Graz
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-white/10 text-[11px]">
                  <span className="text-[#C5A880] font-medium flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {s.hoursWeekday.split(',')[0]}
                  </span>
                  <a
                    href={s.mapsUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[#9EB0A4] hover:text-[#F5F5F0] flex items-center gap-0.5 hover:underline"
                  >
                    <span>Route</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Informational Policy Notice (NO CART / NO ONLINE ORDER) */}
        <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-800/40 flex items-start gap-3 text-xs text-[#9EB0A4] leading-relaxed">
          <ShieldCheck className="w-5 h-5 text-[#C5A880] shrink-0 mt-0.5" />
          <div>
            <strong className="text-[#F5F5F0] font-bold block mb-0.5">
              Reine Sortiments-Information (Kein Online-Verkauf)
            </strong>
            <span>
              Als autorisierter Grazer Fachhändler erfolgt die persönliche Fachberatung und der Verkauf ausschließlich vor Ort gegen amtlichen Altersnachweis (18+).
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
