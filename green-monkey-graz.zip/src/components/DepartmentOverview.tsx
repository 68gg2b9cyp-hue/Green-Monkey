import React from 'react';
import { ProductCategory } from '../types';
import { Flame, Layers, Sparkles, Leaf, ArrowRight, ShieldCheck, Check } from 'lucide-react';

interface DepartmentOverviewProps {
  onSelectCategory: (category: ProductCategory) => void;
  onOpenFullCatalog: () => void;
}

export const DepartmentOverview: React.FC<DepartmentOverviewProps> = ({
  onSelectCategory,
  onOpenFullCatalog,
}) => {
  const departments = [
    {
      id: 'raw' as ProductCategory,
      title: 'RAW Headshop & Rolling Culture',
      tag: 'Kultmarke • Alcoy Spanien',
      icon: <Flame className="w-5 h-5 text-[#C5A880]" />,
      summary: 'Offizielle RAW Holzboxen, Cache Boxes, Metall-Rolling Trays, Six Shooter, Cones & Classic Papers.',
      points: ['Echtholz Cache Boxes & Trays', 'Classic & Black Unbleached Papers', 'Original Cones & Loader Sets'],
      badge: 'Offizieller RAW Händler',
      borderHover: 'hover:border-amber-600/60',
    },
    {
      id: 'filters' as ProductCategory,
      title: 'Aktivkohlefilter & Papiere',
      tag: 'Schadstoffreduzierter Zug',
      icon: <Layers className="w-5 h-5 text-[#DFCAAB]" />,
      summary: 'Purize XTRA Slim im Vorratsglas, ActiTube 6mm & 8mm, OCB Virgin/Organic sowie Marie Blättchen aus Österreich.',
      points: ['Purize Kokosnuss-Aktivkohle', 'ActiTube Originalfilter 6mm / 8mm', 'OCB & Marie Rollen & Tips'],
      badge: 'Großes Filtersortiment',
      borderHover: 'hover:border-slate-400/60',
    },
    {
      id: 'headshop' as ProductCategory,
      title: 'Borosilikat-Glasbongs & Grinder',
      tag: 'Präzision & Glasbläserkunst',
      icon: <Sparkles className="w-5 h-5 text-teal-400" />,
      summary: 'Robuste Panzerglas-Bongs von Jelly Joker, Designer-Rigs von Hemper und präzise CNC-Aluminium-Grinder von Champ High.',
      points: ['Borosilikatglas 5mm & 7mm', 'Perkolatoren, Chillums & Rigs', 'CNC Metall-Grinder 4-teilig'],
      badge: 'Glas & Metall Gear',
      borderHover: 'hover:border-teal-500/60',
    },
    {
      id: 'cbd' as ProductCategory,
      title: 'Bio CBD, Hanfblüten & Cannaline Tees',
      tag: '< 0,3% THC • 100% Legal',
      icon: <Leaf className="w-5 h-5 text-emerald-400" />,
      summary: 'CO2-extrahierte Vollspektrum-Hanftropfen, zertifizierte Hanfblüten sowie Cannaline Bio CBD Kräutertees (Immunity, Relax, Focus, Detox).',
      points: ['Cannaline Bio CBD Tees (Immunity, Relax, Focus, Detox)', 'CO2-Vollspektrum Hanftropfen 10% & 20%', '100% Bio & chargengenau laborgeprüft'],
      badge: 'Bio Hanf & Tee',
      borderHover: 'hover:border-emerald-500/60',
    },
  ];

  return (
    <section className="py-16 md:py-24 border-t border-white/10 relative" id="departments">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="inline-block text-xs font-bold tracking-widest text-[#C5A880] uppercase mb-2 font-heading">
            SORTIMENTS-SCHWERPUNKTE
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl font-bold text-[#F6F4EE] mb-3">
            Die Kernbereiche in unseren Stores
          </h2>
          <p className="text-sm text-[#8E9F94] leading-relaxed">
            Vor Ort in unseren Fachgeschäften am Hauptbahnhof und Jakominiplatz verfügbar.
            Wählen Sie einen Bereich aus oder öffnen Sie die vollständige Übersicht.
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {departments.map((dept) => (
            <div
              key={dept.id}
              className={`bg-[#12281D]/90 backdrop-blur-md border border-white/10 ${dept.borderHover} rounded-2xl p-6 flex flex-col justify-between transition-all duration-300 shadow-xl shadow-black/20 group`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center">
                    {dept.icon}
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#C5A880] bg-[#C5A880]/10 border border-[#C5A880]/30 px-2 py-0.5 rounded">
                    {dept.badge}
                  </span>
                </div>

                <h3 className="font-heading text-lg font-bold text-[#F6F4EE] mb-1">
                  {dept.title}
                </h3>
                <span className="text-xs font-semibold text-[#8E9F94] block mb-3">
                  {dept.tag}
                </span>

                <p className="text-xs text-[#DFDAD0] leading-relaxed mb-4">
                  {dept.summary}
                </p>

                <ul className="flex flex-col gap-2 mb-6 border-t border-white/5 pt-3">
                  {dept.points.map((pt, i) => (
                    <li key={i} className="flex items-center gap-2 text-[11px] text-[#9EB0A4]">
                      <Check className="w-3 h-3 text-[#C5A880] shrink-0" />
                      <span>{pt}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                type="button"
                onClick={() => onSelectCategory(dept.id)}
                className="w-full py-2.5 px-3 rounded-xl text-xs font-bold text-[#DFCAAB] group-hover:text-[#F6F4EE] bg-white/5 group-hover:bg-[#C5A880]/20 border border-white/10 group-hover:border-[#C5A880]/50 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Im Katalog ansehen</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        {/* Global Catalog Launch Banner */}
        <div className="bg-gradient-to-r from-[#163324] via-[#12281D] to-[#0E2016] border border-[#C5A880]/40 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#C5A880]/20 border border-[#C5A880]/40 text-[#DFCAAB] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-heading text-lg sm:text-xl font-bold text-[#F6F4EE] mb-1">
                Vollständiges Sortiment in der Katalog-Ansicht
              </h3>
              <p className="text-xs sm:text-sm text-[#9EB0A4] max-w-xl leading-relaxed">
                Durchsuchen Sie alle lagernden Bongs, Grinder, Filter, Papers, Boxen und Hanfextrakte inklusive genauer technischer Spezifikationen und Store-Bestandsangaben.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenFullCatalog}
            className="shrink-0 px-6 py-3.5 rounded-full text-xs sm:text-sm font-bold btn-gold cursor-pointer inline-flex items-center gap-2 whitespace-nowrap shadow-lg shadow-[#C5A880]/20"
          >
            <span>Katalog öffnen (50+ Artikel)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </section>
  );
};
