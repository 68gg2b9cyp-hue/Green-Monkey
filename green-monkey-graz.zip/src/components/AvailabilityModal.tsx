import React, { useState, useEffect } from 'react';
import { StoreId } from '../types';
import { STORES } from '../data/storeData';
import { ShowcaseProduct } from '../data/luxuryShowcaseData';
import { 
  X, 
  MapPin, 
  Clock, 
  Phone, 
  Navigation, 
  ShieldCheck, 
  CheckCircle2, 
  Store, 
  ExternalLink,
  TrainTrack,
  Sparkles,
  Info
} from 'lucide-react';

interface AvailabilityModalProps {
  product: ShowcaseProduct | null;
  isOpen: boolean;
  onClose: () => void;
  activeStore: StoreId;
  onSelectStore: (storeId: StoreId) => void;
}

function getStoreLiveStatus(storeId: StoreId): { isOpen: boolean; label: string } {
  try {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Europe/Vienna',
      weekday: 'short',
      hour: 'numeric',
      minute: 'numeric',
      hour12: false,
    });
    const parts = formatter.formatToParts(now);
    let weekday = '';
    let hour = 0;
    let minute = 0;
    for (const p of parts) {
      if (p.type === 'weekday') weekday = p.value;
      if (p.type === 'hour') hour = parseInt(p.value, 10);
      if (p.type === 'minute') minute = parseInt(p.value, 10);
    }
    const currentMinutes = hour * 60 + minute;
    const isWithinHours = currentMinutes >= 12 * 60 && currentMinutes < 18 * 60;

    if (storeId === 'annen') {
      const isWeekday = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].includes(weekday);
      const isOpen = isWeekday && isWithinHours;
      return {
        isOpen,
        label: isOpen ? 'Jetzt geöffnet bis 18:00 Uhr' : 'Derzeit geschlossen',
      };
    } else {
      const isMonToSat = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].includes(weekday);
      const isOpen = isMonToSat && isWithinHours;
      return {
        isOpen,
        label: isOpen ? 'Jetzt geöffnet bis 18:00 Uhr' : 'Derzeit geschlossen',
      };
    }
  } catch {
    return { isOpen: false, label: 'Geschlossen' };
  }
}

export const AvailabilityModal: React.FC<AvailabilityModalProps> = ({
  product,
  isOpen,
  onClose,
  activeStore,
  onSelectStore,
}) => {
  const [selectedStoreId, setSelectedStoreId] = useState<StoreId>(activeStore);

  useEffect(() => {
    setSelectedStoreId(activeStore);
  }, [activeStore]);

  if (!isOpen || !product) return null;

  const currentStoreData = STORES.find((s) => s.id === selectedStoreId) || STORES[0];
  const liveStatus = getStoreLiveStatus(selectedStoreId);

  const handleStoreTab = (id: StoreId) => {
    setSelectedStoreId(id);
    onSelectStore(id);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto bg-gradient-to-b from-[#10241A] via-[#0E1F16] to-[#08150E] border border-[#C5A880]/40 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/90 text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Subtle Ambient Radial Lighting */}
        <div className="absolute top-0 right-1/4 w-72 h-36 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -top-1 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#C5A880] to-transparent" />

        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-white/70 hover:text-white bg-black/50 hover:bg-black/80 border border-white/10 transition-colors cursor-pointer z-10"
          aria-label="Schließen"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Header Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider text-[#C5A880] bg-[#C5A880]/15 border border-[#C5A880]/30 font-heading mb-4">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Verfügbarkeitsprüfung im Fachhandel Graz</span>
        </div>

        {/* Selected Product Card Summary */}
        <div className="p-4 rounded-2xl bg-black/40 border border-white/10 mb-6 flex items-start gap-4">
          {product.imageUrl ? (
            <div className="w-16 h-16 rounded-xl bg-white/5 border border-white/10 p-1 flex items-center justify-center shrink-0 overflow-hidden">
              <img
                src={product.imageUrl}
                alt={product.name}
                className="max-h-full max-w-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
          ) : (
            <div className="w-16 h-16 rounded-xl bg-[#C5A880]/15 border border-[#C5A880]/30 flex items-center justify-center shrink-0 text-2xl font-heading text-[#C5A880]">
              🌿
            </div>
          )}

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="text-[10px] font-mono tracking-wider uppercase text-[#C5A880] font-semibold bg-[#C5A880]/15 px-2 py-0.5 rounded border border-[#C5A880]/30">
                {product.group}
              </span>
              <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/70 px-2 py-0.5 rounded border border-emerald-600/30">
                {product.badge}
              </span>
            </div>
            <h3 className="font-heading font-bold text-base sm:text-lg text-[#F6F4EE] leading-tight truncate">
              {product.name}
            </h3>
            <p className="text-xs text-[#9EB0A4] line-clamp-1 mt-0.5">
              {product.subtitle}
            </p>
          </div>
        </div>

        {/* Interactive Dual Store Switcher */}
        <div className="mb-6">
          <div className="text-xs text-[#DFDAD0] font-semibold uppercase tracking-wider mb-2 font-heading flex items-center justify-between">
            <span>Filiale in Graz auswählen:</span>
            <span className="text-[11px] text-[#C5A880] lowercase">2x Standorte vor Ort</span>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {STORES.map((st, idx) => {
              const isSelected = selectedStoreId === st.id;
              const storeLive = getStoreLiveStatus(st.id);

              return (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => handleStoreTab(st.id)}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer relative ${
                    isSelected
                      ? 'bg-[#142E20] border-[#C5A880] shadow-lg shadow-black/40 ring-1 ring-[#C5A880]/50'
                      : 'bg-black/30 border-white/10 hover:border-white/20 text-[#8E9F94]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono text-[10px] font-bold text-[#C5A880]">
                      FILIALE 0{idx + 1}
                    </span>
                    <span
                      className={`w-2 h-2 rounded-full ${
                        storeLive.isOpen
                          ? 'bg-emerald-400 shadow-[0_0_8px_#34D399]'
                          : 'bg-neutral-600'
                      }`}
                    />
                  </div>
                  <div className={`font-heading font-bold text-xs sm:text-sm leading-tight ${isSelected ? 'text-[#F6F4EE]' : 'text-[#DFDAD0]'}`}>
                    {st.shortName}
                  </div>
                  <div className="text-[11px] text-[#8E9F94] mt-0.5 truncate">
                    {st.address}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Store Detailed Info Card */}
        <div className="p-5 rounded-2xl bg-[#091E13]/90 border border-emerald-800/50 mb-6 space-y-3.5">
          {/* Status & Name */}
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <h4 className="font-heading font-bold text-base text-[#F6F4EE]">
                {currentStoreData.name}
              </h4>
              <p className="text-xs text-[#C5A880] font-mono mt-0.5">
                {currentStoreData.tagline}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  liveStatus.isOpen
                    ? 'bg-emerald-400 shadow-[0_0_10px_#34D399] animate-pulse'
                    : 'bg-neutral-600'
                }`}
              />
              <span className={`text-xs font-bold ${liveStatus.isOpen ? 'text-emerald-400' : 'text-neutral-400'}`}>
                {liveStatus.label}
              </span>
            </div>
          </div>

          {/* Address & Tram */}
          <div className="space-y-2 text-xs sm:text-sm">
            <div className="flex items-start gap-2.5 text-[#DFDAD0]">
              <MapPin className="w-4 h-4 text-[#C5A880] shrink-0 mt-0.5" />
              <div>
                <strong className="text-white">{currentStoreData.address}</strong>, {currentStoreData.postalCode} {currentStoreData.city}
              </div>
            </div>

            <div className="flex items-start gap-2.5 text-[#8E9F94] text-xs">
              <TrainTrack className="w-4 h-4 text-[#DFCAAB] shrink-0 mt-0.5" />
              <div>{currentStoreData.tramInfo}</div>
            </div>

            <div className="flex items-start gap-2.5 text-[#DFDAD0]">
              <Clock className="w-4 h-4 text-[#C5A880] shrink-0 mt-0.5" />
              <div>
                <span>{currentStoreData.hoursWeekday}</span>
                <span className="text-[#8E9F94] ml-2 font-mono">({currentStoreData.hoursWeekend})</span>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
          <a
            href={currentStoreData.mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-gold py-3 px-4 rounded-xl font-heading font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#C5A880]/20"
          >
            <Navigation className="w-4 h-4" />
            <span>Google Maps Route</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <a
            href={`tel:${currentStoreData.phone}`}
            className="py-3 px-4 rounded-xl font-heading font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#C5A880] text-white transition-colors cursor-pointer"
          >
            <Phone className="w-4 h-4 text-[#C5A880]" />
            <span>Filiale anrufen</span>
          </a>
        </div>

        {/* Compliance Note */}
        <div className="p-3.5 rounded-xl bg-black/50 border border-white/5 flex items-start gap-2.5 text-[11px] text-[#9EB0A4] leading-relaxed">
          <Info className="w-4 h-4 text-[#C5A880] shrink-0 mt-0.5" />
          <div>
            <strong>Reines Informations-Showcase:</strong> Kein Online-Shop, kein Versand. Artikel können direkt vor Ort in unseren Grazer Filialen besichtigt, geprüft und bar oder mit Karte erworben werden (Verkauf ab 18 Jahren).
          </div>
        </div>

      </div>
    </div>
  );
};
