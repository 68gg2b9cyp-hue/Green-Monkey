import React from 'react';
import { ShieldCheck, Microscope, UserCheck, CheckCircle2, ArrowRight } from 'lucide-react';

interface QualityPillarsSectionProps {
  onOpenCatalog: () => void;
}

export const QualityPillarsSection: React.FC<QualityPillarsSectionProps> = ({ onOpenCatalog }) => {
  const pillars = [
    {
      icon: <ShieldCheck className="w-5 h-5 text-[#C5A880]" />,
      title: '100% Autorisierte Markenware',
      subtitle: 'Direkt vom Hersteller ohne Plagiate',
      description:
        'Wir führen ausnahmslos Originalware von Weltmarken wie RAW, OCB, Purize, ActiTube, Clipper, Best Buds und Champ High. Kein minderwertiger Ausschuss, keine gefälschten Filter oder Billig-Papiere.',
      highlight: 'Zertifizierte Händler-Originale',
    },
    {
      icon: <Microscope className="w-5 h-5 text-emerald-400" />,
      title: 'Laborgeprüfter EU-Nutzhanf',
      subtitle: '< 0,3% THC nach österreichischem Recht',
      description:
        'Alle CBD-Öle, Extrakte und Aromablüten in unseren Stores stammen aus kontrolliertem Anbau und werden von akkreditierten Prüflaboren chargengenau auf Reinheit und Cannabinoid-Gehalt analysiert.',
      highlight: 'Lückenlose Analysenzertifikate',
    },
    {
      icon: <UserCheck className="w-5 h-5 text-blue-400" />,
      title: 'Persönliche Fachberatung vor Ort',
      subtitle: 'Diskret, kompetent & ohne Kaufdruck',
      description:
        'Bei uns müssen Sie die Katze nicht im Sack kaufen. Sie können Glasbongs, Grinder, Cones und Zubehörteile vor Ort in Ruhe ansehen, Schliffe prüfen und sich individuell informieren lassen.',
      highlight: '2x zentrale Filialen in Graz',
    },
  ];

  return (
    <section className="py-14 md:py-20 border-t border-white/10 relative" id="quality">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <span className="inline-block text-xs font-bold tracking-widest text-[#C5A880] uppercase mb-2 font-heading">
              TRANSPARENZ &amp; QUALITÄTSSTANDARD
            </span>
            <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl font-bold text-[#F6F4EE]">
              Warum Kunden Green Monkey in Graz vertrauen
            </h2>
          </div>
          <button
            type="button"
            onClick={onOpenCatalog}
            className="inline-flex items-center gap-2 text-xs font-bold px-5 py-2.5 rounded-full btn-gold self-start md:self-auto cursor-pointer"
          >
            <span>Katalog ansehen</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 3 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {pillars.map((pillar, idx) => (
            <div
              key={idx}
              className="bg-[#12281D]/90 backdrop-blur-md border border-white/10 hover:border-[#C5A880]/40 rounded-2xl p-6 sm:p-7 flex flex-col justify-between transition-all duration-200 shadow-xl shadow-black/20"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center mb-4">
                  {pillar.icon}
                </div>

                <h3 className="font-heading text-lg font-bold text-[#F6F4EE] mb-1">
                  {pillar.title}
                </h3>
                <span className="text-xs font-semibold text-[#DFCAAB] block mb-3">
                  {pillar.subtitle}
                </span>

                <p className="text-xs text-[#9EB0A4] leading-relaxed mb-6">
                  {pillar.description}
                </p>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center gap-2 text-[11px] font-semibold text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>{pillar.highlight}</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
