import React from 'react';
import { StoreId } from '../types';
import { STORES } from '../data/storeData';
import { Clock, MapPin, Phone, ShieldCheck, Navigation } from 'lucide-react';

interface HomeStoreStatusBarProps {
  activeStore: StoreId;
  onSelectStore: (id: StoreId) => void;
}

export const HomeStoreStatusBar: React.FC<HomeStoreStatusBarProps> = ({
  activeStore,
  onSelectStore,
}) => {
  // Determine day in Austria / Graz
  const now = new Date();
  const day = now.getDay(); // 0: Sun, 1: Mon, ... 6: Sat
  const isSunday = day === 0;
  const isSaturday = day === 6;

  return (
    <section className="py-6 bg-[#0B1A12]/90 border-t border-b border-white/10 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 items-center">
          
          {/* Status 1: Annenstraße 68 (Hauptbahnhof) */}
          <div
            onClick={() => onSelectStore('annen')}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
              activeStore === 'annen'
                ? 'bg-[#12281D] border-[#C5A880]/50 shadow-md'
                : 'bg-black/30 border-white/5 hover:border-white/20'
            }`}
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
              <MapPin className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1 mb-0.5">
                <span className="font-heading font-bold text-sm text-[#F6F4EE] truncate">
                  Hauptbahnhof Store
                </span>
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    isSunday || isSaturday
                      ? 'bg-neutral-800 text-neutral-400'
                      : 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                  }`}
                >
                  {isSunday || isSaturday ? 'Am Wochenende zu' : 'Mo–Fr 12:00–18:00'}
                </span>
              </div>
              <p className="text-[#8E9F94] text-[11px] truncate mb-1.5">
                Annenstraße 68, 8020 Graz (Bim 1, 3, 6, 7)
              </p>
              <div className="flex items-center gap-3 text-[11px]">
                <a
                  href="tel:+43316584022"
                  onClick={(e) => e.stopPropagation()}
                  className="inline-flex items-center gap-1 text-[#DFCAAB] hover:underline"
                >
                  <Phone className="w-3 h-3" />
                  +43 316 584 022
                </a>
                <a
                  href={STORES[0].mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="inline-flex items-center gap-1 text-[#8E9F94] hover:text-[#F6F4EE]"
                >
                  <Navigation className="w-3 h-3" />
                  Route
                </a>
              </div>
            </div>
          </div>

          {/* Status 2: Radetzkystraße 13 (Jakominiplatz) */}
          <div
            onClick={() => onSelectStore('jako')}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
              activeStore === 'jako'
                ? 'bg-[#12281D] border-[#C5A880]/50 shadow-md'
                : 'bg-black/30 border-white/5 hover:border-white/20'
            }`}
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
              <MapPin className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1 mb-0.5">
                <span className="font-heading font-bold text-sm text-[#F6F4EE] truncate">
                  Jakominiplatz Store
                </span>
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    isSunday
                      ? 'bg-neutral-800 text-neutral-400'
                      : 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                  }`}
                >
                  {isSunday ? 'Sonntag geschlossen' : 'Mo–Sa 12:00–18:00'}
                </span>
              </div>
              <p className="text-[#8E9F94] text-[11px] truncate mb-1.5">
                Radetzkystraße 13, 8010 Graz (Zentraler Knoten)
              </p>
              <div className="flex items-center gap-3 text-[11px]">
                <a
                  href="tel:+43316823044"
                  onClick={(e) => e.stopPropagation()}
                  className="inline-flex items-center gap-1 text-[#DFCAAB] hover:underline"
                >
                  <Phone className="w-3 h-3" />
                  +43 316 823 044
                </a>
                <a
                  href={STORES[1].mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="inline-flex items-center gap-1 text-[#8E9F94] hover:text-[#F6F4EE]"
                >
                  <Navigation className="w-3 h-3" />
                  Route
                </a>
              </div>
            </div>
          </div>

          {/* Compliance & Store Guarantee Card */}
          <div className="p-3.5 rounded-xl border border-white/10 bg-[#12281D]/60 flex items-center gap-3 md:col-span-2 lg:col-span-1">
            <div className="w-8 h-8 rounded-lg bg-[#C5A880]/20 border border-[#C5A880]/40 text-[#DFCAAB] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="font-heading font-bold text-xs text-[#F6F4EE] block mb-0.5">
                Verkauf &amp; Beratung ab 18 Jahren
              </span>
              <p className="text-[#8E9F94] text-[11px] leading-snug">
                Offizieller Fachhandel vor Ort. Geprüfte Originalware, keine Fake-Produkte, kein unpersönlicher Online-Versand.
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
