import React from 'react';
import { ProductCategory } from '../types';
import { Flame, Sparkles, Box, Check, ArrowRight, ShieldCheck } from 'lucide-react';

interface RawHighlightSectionProps {
  onSelectBrand: (brand: string) => void;
  onSelectCategory: (category: ProductCategory) => void;
}

export const RawHighlightSection: React.FC<RawHighlightSectionProps> = ({
  onSelectBrand,
  onSelectCategory,
}) => {
  const handleOpenRawCatalog = () => {
    onSelectBrand('RAW');
    onSelectCategory('raw');
    const catalogEl = document.getElementById('catalog');
    if (catalogEl) {
      catalogEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-14 bg-gradient-to-b from-[#122418] via-[#1a1c14] to-[#0f2218] border-t border-b border-amber-800/30 relative overflow-hidden" id="raw-highlight">
      {/* Background glow */}
      <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="bg-gradient-to-br from-[#1a1712]/95 via-[#16271c]/95 to-[#0b1810]/95 rounded-3xl border border-amber-600/30 p-6 sm:p-10 lg:p-12 shadow-2xl relative overflow-hidden">
          
          {/* Top Label */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-6 border-b border-white/10 mb-8">
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse shadow-[0_0_10px_#F59E0B]" />
              <span className="text-xs font-black tracking-widest text-[#DFCAAB] uppercase bg-amber-950/60 border border-amber-700/50 px-3 py-1 rounded-full font-heading">
                ★ STORE-FOKUS: OFFIZIELLES RAW SORTIMENT &amp; MERCH
              </span>
            </div>
            <div className="text-xs font-semibold text-[#8E9F94] bg-black/40 px-3 py-1 rounded-full border border-white/10">
              Im Schaufenster &amp; in beiden Grazer Filialen
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            
            {/* Left Showcase Box */}
            <div className="lg:col-span-5 flex flex-col items-center justify-center">
              <div className="relative w-full aspect-square max-w-sm rounded-2xl bg-gradient-to-b from-amber-950/40 via-[#1a1712] to-black/90 border border-amber-600/40 p-8 flex flex-col items-center justify-center text-center shadow-2xl group">
                
                {/* Visual Icon Art */}
                <div className="text-6xl sm:text-7xl mb-3 group-hover:scale-110 transition-transform duration-500 drop-shadow-[0_0_25px_rgba(217,119,6,0.3)]">
                  🪵📜✨
                </div>

                <div className="font-heading font-black text-2xl sm:text-3xl text-[#F6F4EE] mb-1">
                  RAW® THE NATURAL WAY
                </div>
                <div className="font-heading font-bold text-xs tracking-widest text-amber-300 uppercase mb-3">
                  UNREFINED ROLLING PAPERS &amp; ACCESSORIES
                </div>

                <p className="text-xs text-[#9EB0A4] leading-relaxed mb-4">
                  Trays mit Magnetschutz, massive Naturholz-Cache-Boxen, 16oz Mason Jars, Cones &amp; Black Connoisseur Papers.
                </p>

                <div className="bg-[#09140E]/90 border border-amber-600/30 px-4 py-2 rounded-xl text-center w-full">
                  <span className="text-[11px] text-amber-300 font-bold uppercase tracking-wider block">
                    Vollständige RAW Kollektion
                  </span>
                  <span className="text-[11px] text-[#9EB0A4] block mt-0.5">
                    Originalware direkt aus Alcoy, Spanien
                  </span>
                </div>
              </div>
            </div>

            {/* Right Details */}
            <div className="lg:col-span-7 flex flex-col justify-between">
              <div>
                <div className="inline-flex items-center gap-1.5 text-xs font-extrabold tracking-widest text-[#C5A880] uppercase mb-2 font-heading">
                  <Flame className="w-4 h-4 text-amber-400" />
                  VIELFALT DER KULTMARKE IN GRAZ
                </div>

                <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-[#F6F4EE] mb-3 leading-tight">
                  RAW Trays, Holzboxen, Papers &amp; Cones
                </h2>

                <p className="text-sm sm:text-base text-[#DFDAD0] leading-relaxed mb-6">
                  In unseren Filialen am Hauptbahnhof und Jakominiplatz finden Sie eine der umfangreichsten RAW-Präsentationen in Österreich: Von den klassischen <strong>Black Gold &amp; Artist Metall-Trays</strong> mit Magnet-Deckeln über <strong>massive Holz-Aufbewahrungsboxen</strong> und <strong>Mason Jars</strong> bis hin zu Cones aller Größen und praktischen Gadgets wie dem RAW Six Shooter.
                </p>

                {/* Highlights list */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
                  <div className="flex items-start gap-2.5 p-3 rounded-xl bg-white/5 border border-white/10">
                    <Box className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-xs font-bold text-[#F6F4EE] block">RAW Cache Boxes &amp; Holz-Caddies</strong>
                      <span className="text-[11px] text-[#9EB0A4]">Naturholz-Schatullen passgenau für Bautabletts.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-3 rounded-xl bg-white/5 border border-white/10">
                    <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-xs font-bold text-[#F6F4EE] block">Trays mit Magnet-Cover</strong>
                      <span className="text-[11px] text-[#9EB0A4]">Staub- und geruchsdichter Magnetschutzdeckel.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-3 rounded-xl bg-white/5 border border-white/10">
                    <Check className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-xs font-bold text-[#F6F4EE] block">RAW Black &amp; Organic Papers</strong>
                      <span className="text-[11px] text-[#9EB0A4]">Doppelt gepresst für feinsten Eigengeschmack.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-3 rounded-xl bg-white/5 border border-white/10">
                    <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-xs font-bold text-[#F6F4EE] block">100% Originale Markenware</strong>
                      <span className="text-[11px] text-[#9EB0A4]">Keine Fälschungen, autorisierter Fachhandel.</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-6 border-t border-white/10">
                <button
                  type="button"
                  onClick={handleOpenRawCatalog}
                  className="btn-gold px-6 py-3.5 rounded-full text-xs sm:text-sm font-bold flex items-center justify-center gap-2 cursor-pointer shadow-xl shadow-[#C5A880]/20"
                >
                  <span>RAW Artikel im Katalog filtern</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <a
                  href="#stores"
                  className="px-5 py-3.5 rounded-full text-xs font-bold text-[#DFDAD0] hover:text-[#F6F4EE] border border-white/20 hover:border-[#C5A880] text-center transition-colors"
                >
                  Filialen &amp; Öffnungszeiten ansehen ↗
                </a>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};
