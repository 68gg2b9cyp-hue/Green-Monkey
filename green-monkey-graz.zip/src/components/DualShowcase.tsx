import React from 'react';
import { ProductCategory } from '../types';
import { Check, HeartPulse, Flame, Leaf, Store } from 'lucide-react';

interface DualShowcaseProps {
  onSelectCategory: (category: ProductCategory) => void;
}

export const DualShowcase: React.FC<DualShowcaseProps> = ({ onSelectCategory }) => {
  const handleFilterClick = (cat: ProductCategory) => {
    onSelectCategory(cat);
    const catalogEl = document.getElementById('catalog');
    if (catalogEl) {
      catalogEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-16 md:py-24 border-t border-white/10 relative" id="wellness">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs font-bold tracking-widest text-[#C5A880] uppercase mb-2 font-heading">
            ZWEI SCHWERPUNKTE IM GRAZER FACHHANDEL
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl font-bold text-[#F6F4EE] mb-3">
            Naturheilkunde &amp; moderne Rauchkultur
          </h2>
          <p className="text-sm sm:text-base text-[#DFDAD0] leading-relaxed">
            Vor Ort in unseren beiden Grazer Filialen: Ausgewählte Bio-CBD Öle für Ihr Wohlbefinden sowie ein riesiges Sortiment an originalem Headshop-Zubehör führender Weltmarken.
          </p>
        </div>

        {/* Dual Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Pillar 1: Wellness & CBD */}
          <div className="bg-[#12281D]/90 border border-[#C5A880]/20 hover:border-[#C5A880]/40 rounded-3xl p-6 sm:p-10 transition-all duration-300 flex flex-col justify-between shadow-xl relative overflow-hidden group">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 via-[#C5A880] to-emerald-400" />

            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold tracking-wider text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-3 py-1 rounded-full mb-4">
                <HeartPulse className="w-3.5 h-3.5" />
                <span>BIO-CBD &amp; WELLNESS</span>
              </div>

              <h3 className="font-heading text-2xl sm:text-3xl font-bold text-[#F6F4EE] mb-3">
                Für Wohlbefinden, Schlaf &amp; Vitalität
              </h3>

              <p className="text-xs sm:text-sm text-[#DFDAD0] leading-relaxed mb-6">
                Zertifizierte Vollspektrum-CBD Öle und Hanfprodukte zur Unterstützung der natürlichen Erholung und Entspannung.
                Persönliche, diskrete Beratung vor Ort in Graz.
              </p>

              <ul className="flex flex-col gap-3.5 mb-8">
                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3 h-3" />
                  </div>
                  <div>
                    <strong className="text-xs sm:text-sm font-bold text-[#F6F4EE] block">
                      Vollspektrum Bio-Hanftropfen
                    </strong>
                    <p className="text-xs text-[#8E9F94] mt-0.5">
                      10% &amp; 20% Formulierungen mit natürlichem Entourage-Effekt, schonend CO2-extrahiert.
                    </p>
                  </div>
                </li>

                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3 h-3" />
                  </div>
                  <div>
                    <strong className="text-xs sm:text-sm font-bold text-[#F6F4EE] block">
                      Cannaline Bio Kräutertees
                    </strong>
                    <p className="text-xs text-[#8E9F94] mt-0.5">
                      Kombination aus europäischem Nutzhanf und Arzneikräutern für Immunity, Focus, Relax und Detox.
                    </p>
                  </div>
                </li>

                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3 h-3" />
                  </div>
                  <div>
                    <strong className="text-xs sm:text-sm font-bold text-[#F6F4EE] block">
                      100% Rechtskonform (&lt; 0,3% THC)
                    </strong>
                    <p className="text-xs text-[#8E9F94] mt-0.5">
                      Chargengenaue Laboranalysen aus akkreditierten Instituten garantieren maximale Sicherheit.
                    </p>
                  </div>
                </li>
              </ul>
            </div>

            <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs text-[#8E9F94] flex items-center gap-1.5">
                <Store className="w-3.5 h-3.5 text-[#C5A880]" />
                Verfügbar in beiden Grazer Filialen
              </span>
              <button
                type="button"
                onClick={() => handleFilterClick('cbd')}
                className="text-xs font-bold px-4 py-2 rounded-full btn-outline-gold cursor-pointer"
              >
                CBD-Produkte ansehen
              </button>
            </div>
          </div>

          {/* Pillar 2: Headshop & Lifestyle */}
          <div className="bg-[#161a17]/90 border border-amber-600/20 hover:border-amber-600/40 rounded-3xl p-6 sm:p-10 transition-all duration-300 flex flex-col justify-between shadow-xl relative overflow-hidden group">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-[#C5A880] to-yellow-500" />

            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold tracking-wider text-[#DFCAAB] bg-amber-950/60 border border-amber-600/30 px-3 py-1 rounded-full mb-4">
                <Flame className="w-3.5 h-3.5" />
                <span>RAUCHKULTUR &amp; HEADSHOP</span>
              </div>

              <h3 className="font-heading text-2xl sm:text-3xl font-bold text-[#F6F4EE] mb-3">
                Originale Weltmarken &amp; Qualitäts-Equipment
              </h3>

              <p className="text-xs sm:text-sm text-[#DFDAD0] leading-relaxed mb-6">
                Vollständige Sortimente von RAW®, OCB, Purize, ActiTube, Marie und Champ High.
                Qualität, die man spürt – vom Papier bis zur massiven Borosilikat-Glasbong.
              </p>

              <ul className="flex flex-col gap-3.5 mb-8">
                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-amber-500/20 text-[#DFCAAB] flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3 h-3" />
                  </div>
                  <div>
                    <strong className="text-xs sm:text-sm font-bold text-[#F6F4EE] block">
                      RAW® Headshop-Erlebniswelt
                    </strong>
                    <p className="text-xs text-[#8E9F94] mt-0.5">
                      Cache Boxes, Metall-Rolling Trays, Cones, Loader Sets und original ungebleichte Papiere.
                    </p>
                  </div>
                </li>

                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-amber-500/20 text-[#DFCAAB] flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3 h-3" />
                  </div>
                  <div>
                    <strong className="text-xs sm:text-sm font-bold text-[#F6F4EE] block">
                      Aktivkohlefilter im Vorratsglas
                    </strong>
                    <p className="text-xs text-[#8E9F94] mt-0.5">
                      Purize XTRA Slim (All Colors, 250er &amp; 690er Gläser) sowie ActiTube 6mm &amp; 8mm.
                    </p>
                  </div>
                </li>

                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-amber-500/20 text-[#DFCAAB] flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3 h-3" />
                  </div>
                  <div>
                    <strong className="text-xs sm:text-sm font-bold text-[#F6F4EE] block">
                      Glasbongs, Grinder &amp; Accessoires
                    </strong>
                    <p className="text-xs text-[#8E9F94] mt-0.5">
                      Borosilikatglas von Jelly Joker &amp; Hemper, 4-teilige CNC-Grinder und Clipper Feuerzeuge.
                    </p>
                  </div>
                </li>
              </ul>
            </div>

            <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs text-[#8E9F94] flex items-center gap-1.5">
                <Store className="w-3.5 h-3.5 text-[#C5A880]" />
                Verfügbar in beiden Grazer Filialen
              </span>
              <button
                type="button"
                onClick={() => handleFilterClick('raw')}
                className="text-xs font-bold px-4 py-2 rounded-full btn-gold cursor-pointer"
              >
                Headshop-Sortiment ansehen
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
