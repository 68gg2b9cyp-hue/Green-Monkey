import React, { useState } from 'react';
import { 
  SHOWCASE_CATEGORIES, 
  LUXURY_PRODUCTS, 
  ShowcaseCategory, 
  ShowcaseProduct 
} from '../data/luxuryShowcaseData';
import { ShowcaseProductCard } from './ShowcaseProductCard';
import { ProductDetailModal } from './ProductDetailModal';
import { AvailabilityModal } from './AvailabilityModal';
import { StoreId } from '../types';
import { 
  Search, 
  Sparkles, 
  ShieldCheck, 
  Store, 
  Filter, 
  Check, 
  ArrowRight,
  Info,
  Flame,
  Zap,
  Leaf,
  Moon,
  ChevronRight,
  ExternalLink,
  MapPin,
  Clock,
  Layers,
  Award
} from 'lucide-react';

interface LuxuryProductShowcaseProps {
  initialCategory?: string;
  activeStore?: StoreId;
  onSelectStore?: (storeId: StoreId) => void;
}

export const LuxuryProductShowcase: React.FC<LuxuryProductShowcaseProps> = ({
  activeStore = 'annen',
  onSelectStore = () => {},
}) => {
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Modals state
  const [activeDetailProduct, setActiveDetailProduct] = useState<ShowcaseProduct | null>(null);
  const [activeAvailabilityProduct, setActiveAvailabilityProduct] = useState<ShowcaseProduct | null>(null);

  const filteredCategories: ShowcaseCategory[] = SHOWCASE_CATEGORIES.filter((cat) => {
    if (selectedCategoryId === 'all') return true;
    return cat.id === selectedCategoryId;
  });

  const getFilteredProductsForCategory = (categoryId: string) => {
    return LUXURY_PRODUCTS.filter((item) => {
      if (item.category !== categoryId) return false;
      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase().trim();
      return (
        item.name.toLowerCase().includes(q) ||
        item.subtitle.toLowerCase().includes(q) ||
        item.group.toLowerCase().includes(q) ||
        item.badge.toLowerCase().includes(q) ||
        item.details.toLowerCase().includes(q)
      );
    });
  };

  const totalFilteredCount = LUXURY_PRODUCTS.filter((item) => {
    const matchesCat = selectedCategoryId === 'all' || item.category === selectedCategoryId;
    if (!matchesCat) return false;
    if (!searchQuery.trim()) return true;

    const q = searchQuery.toLowerCase().trim();
    return (
      item.name.toLowerCase().includes(q) ||
      item.subtitle.toLowerCase().includes(q) ||
      item.group.toLowerCase().includes(q) ||
      item.badge.toLowerCase().includes(q)
    );
  }).length;

  // Curated Hero Spotlight items for each zone
  const zoneSpotlights: Record<string, {
    productId: string;
    curatorQuote: string;
    brandVibe: string;
    vibeBadge: string;
    tagColor: string;
  }> = {
    wellness: {
      productId: 'tea-immunity',
      curatorQuote: '„Biologischer Vollspektrum-Hanf vereint mit alpiner Kräutertradition – das Aushängeschild unserer Grazer Wellness-Kuration.“',
      brandVibe: 'Marley Natural Organic Warmth × Green Thumb Botanical Purity',
      vibeBadge: 'CBD Balance • Bio 100%',
      tagColor: 'border-emerald-500/40 text-emerald-300 bg-emerald-950/60',
    },
    vape: {
      productId: 'dev-xmax-v3-pro',
      curatorQuote: '„Reine Konvektionserhitzung ohne Verbrennung – kompromisslose Dampfreinheit für anspruchsvolle Genießer.“',
      brandVibe: 'Cyber-Sleek Dark Mode × GTi Precision Engineering',
      vibeBadge: 'Precision Convection • USB-C',
      tagColor: 'border-cyan-500/40 text-cyan-300 bg-cyan-950/60',
    },
    headshop: {
      productId: 'tray-raw-wooden',
      curatorQuote: '„Echtes Akazienholz, gefräste Bauschale und Magnetschnappverschluss. Das Nonplusultra für authentische Drehkultur.“',
      brandVibe: 'RAW Unrefined Rolling Culture × Hemper Art Glass',
      vibeBadge: 'RAW Approved • Handcrafted Wood',
      tagColor: 'border-amber-500/40 text-amber-300 bg-amber-950/60',
    },
    smartshop: {
      productId: 'herb-blue-lotus',
      curatorQuote: '„Traditionelle ägyptische Zeremonialblüte im Miron-Violettglas – lebendige Ethnobotanik zum Anfassen und Riechen.“',
      brandVibe: 'Marley Natural Earthy Aesthetics × Eco-Lifestyle Decor',
      vibeBadge: 'Sacred Botanical • Miron Glass',
      tagColor: 'border-purple-500/40 text-purple-300 bg-purple-950/60',
    },
  };

  return (
    <section 
      className="py-16 md:py-24 bg-[#0B1E13] border-t border-emerald-900/40 relative overflow-hidden" 
      id="catalog"
    >
      {/* Background Subtle Ambient Gradients */}
      <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-emerald-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-10 w-[700px] h-[700px] bg-[#14291D]/40 rounded-full blur-3xl pointer-events-none" />

      {/* 1. Creative Marquee Ticker: RAW × GTi × Marley Natural Vibe */}
      <div className="w-full bg-[#08170E] border-y border-[#C5A880]/20 py-2.5 overflow-hidden mb-12 relative shadow-lg">
        <div className="flex whitespace-nowrap animate-marquee items-center gap-8 text-xs font-mono font-bold tracking-widest uppercase text-[#DFCAAB]">
          <span className="flex items-center gap-2 text-[#C5A880]">
            <Flame className="w-3.5 h-3.5 text-amber-500" />
            <span>RAW® THE NATURAL WAY</span>
          </span>
          <span className="text-white/20">•</span>
          <span className="flex items-center gap-2 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_#34D399]" />
            <span>GREEN THUMB DARK-EMERALD LUXURY</span>
          </span>
          <span className="text-white/20">•</span>
          <span className="flex items-center gap-2 text-[#DFCAAB]">
            <Leaf className="w-3.5 h-3.5 text-[#C5A880]" />
            <span>MARLEY NATURAL WARMTH &amp; BOTANICALS</span>
          </span>
          <span className="text-white/20">•</span>
          <span className="text-white/80 font-heading font-black">2x STORES IN GRAZ</span>
          <span className="text-white/20">•</span>
          <span className="text-emerald-300 font-bold">HAUPTBAHNHOF &amp; JAKOMINIPLATZ</span>
          <span className="text-white/20">•</span>
          <span className="text-amber-400">KEIN ONLINE-SHOP • REINES INFORMATIONS-MUSEUM</span>
          <span className="text-white/20">•</span>
          <span className="text-[#C5A880]">BEST BUDS • HEMPER • PURIZE • CANNALINE • OCB • MARIE</span>
          <span className="text-white/20">•</span>
          <span className="flex items-center gap-2 text-[#C5A880]">
            <Flame className="w-3.5 h-3.5 text-amber-500" />
            <span>RAW® THE NATURAL WAY</span>
          </span>
          <span className="text-white/20">•</span>
          <span className="flex items-center gap-2 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_#34D399]" />
            <span>GREEN THUMB DARK-EMERALD LUXURY</span>
          </span>
          <span className="text-white/20">•</span>
          <span className="flex items-center gap-2 text-[#DFCAAB]">
            <Leaf className="w-3.5 h-3.5 text-[#C5A880]" />
            <span>MARLEY NATURAL WARMTH &amp; BOTANICALS</span>
          </span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header: Creative Hybrid Concept */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-12 pb-8 border-b border-emerald-800/40">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold tracking-widest text-[#C5A880] uppercase bg-[#C5A880]/15 border border-[#C5A880]/30 font-heading mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>DIGITAL MAGAZINE &amp; PRODUKT-MUSEUM • GRAZ</span>
            </div>

            <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-extrabold text-[#F5F5F0] tracking-tight leading-tight">
              Kuratierte Zonen &amp; Schaufenster
            </h2>

            <p className="text-sm sm:text-base text-[#9EB0A4] mt-3 leading-relaxed">
              Erleben Sie das gesamte Produktspektrum unserer beiden Grazer Fachgeschäfte in vier interaktiven Konzeptzonen: 
              Von bioaktiver Naturheilkunde über High-Tech Vaporizer und unraffinierte RAW-Drehkultur bis zu exotischer Ethnobotanik.
            </p>
          </div>

          {/* Compliance & Store Quick Indicator */}
          <div className="bg-[#0A170F]/90 border border-emerald-800/50 rounded-2xl p-4 lg:max-w-sm flex items-start gap-3 shadow-lg">
            <ShieldCheck className="w-5 h-5 text-[#C5A880] shrink-0 mt-0.5" />
            <div className="text-xs text-[#9EB0A4] leading-relaxed">
              <strong className="text-[#F5F5F0] block font-heading font-bold mb-0.5">
                Kein Warenkorb • Nur vor Ort in Graz
              </strong>
              Transparenter Katalog ohne Online-Verkauf. Persönliche Beratung, Haptik und sofortige Mitnahme an unseren beiden Standorten ab 18 Jahren.
            </div>
          </div>
        </div>

        {/* Controls: Category Filter Tabs & Search Bar */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-14">
          
          {/* Category Tabs with Brand Badges */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            <button
              type="button"
              onClick={() => setSelectedCategoryId('all')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold font-heading whitespace-nowrap transition-all cursor-pointer ${
                selectedCategoryId === 'all'
                  ? 'bg-gradient-to-r from-[#DFCAAB] to-[#C5A880] text-[#07150D] shadow-lg shadow-[#C5A880]/20'
                  : 'bg-[#10241A] text-[#9EB0A4] hover:text-[#F5F5F0] border border-emerald-800/40 hover:border-emerald-700'
              }`}
            >
              Alle 4 Zonen ({LUXURY_PRODUCTS.length})
            </button>

            {SHOWCASE_CATEGORIES.map((cat) => {
              const count = LUXURY_PRODUCTS.filter((p) => p.category === cat.id).length;
              const isActive = selectedCategoryId === cat.id;

              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategoryId(cat.id)}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold font-heading whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
                    isActive
                      ? 'bg-gradient-to-r from-[#DFCAAB] to-[#C5A880] text-[#07150D] shadow-lg shadow-[#C5A880]/20'
                      : 'bg-[#10241A] text-[#9EB0A4] hover:text-[#F5F5F0] border border-emerald-800/40 hover:border-emerald-700'
                  }`}
                >
                  <span className="text-sm">{cat.icon}</span>
                  <span>{cat.categoryName}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${isActive ? 'bg-[#07150D]/20 text-[#07150D]' : 'bg-black/40 text-[#8E9F94]'}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Search Input */}
          <div className="relative min-w-[240px] sm:min-w-[280px]">
            <Search className="w-4 h-4 text-[#8E9F94] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Sortiment, Marke oder Kraut suchen..."
              className="w-full bg-[#10241A] border border-emerald-800/40 focus:border-[#C5A880] rounded-xl pl-10 pr-8 py-2.5 text-xs text-[#F5F5F0] placeholder-[#8E9F94] outline-none transition-colors"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#8E9F94] hover:text-[#F5F5F0]"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Zero Results State */}
        {totalFilteredCount === 0 && (
          <div className="text-center py-20 bg-[#10241A]/50 border border-emerald-800/40 rounded-3xl p-8 mb-16">
            <Info className="w-10 h-10 text-[#C5A880] mx-auto mb-3 opacity-80" />
            <h3 className="font-heading text-lg font-bold text-[#F5F5F0] mb-1">
              Keine Artikel gefunden
            </h3>
            <p className="text-xs text-[#9EB0A4] max-w-md mx-auto mb-5">
              Für Ihren Suchbegriff &quot;{searchQuery}&quot; liegen im ausgewählten Sortiment keine Einträge vor.
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedCategoryId('all');
              }}
              className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#C5A880] text-[#07150D] cursor-pointer"
            >
              Filter zurücksetzen
            </button>
          </div>
        )}

        {/* The 4 Zones with Non-Standard Magazine Layouts */}
        <div className="space-y-28">
          {filteredCategories.map((category, catIndex) => {
            const categoryProducts = getFilteredProductsForCategory(category.id);
            if (categoryProducts.length === 0) return null;

            const spotlightMeta = zoneSpotlights[category.id];
            const spotlightProduct = spotlightMeta 
              ? categoryProducts.find(p => p.id === spotlightMeta.productId) || categoryProducts[0]
              : categoryProducts[0];

            return (
              <div
                key={category.id}
                className="scroll-mt-28"
                id={`cat-${category.id}`}
              >
                {/* 1. Zone Header Banner */}
                <div className="bg-gradient-to-r from-[#12281D]/95 via-[#0F2218]/95 to-[#0A1811]/95 border border-emerald-800/40 rounded-3xl p-6 sm:p-8 md:p-10 mb-8 shadow-xl relative overflow-hidden">
                  <div className="absolute right-0 top-0 w-80 h-full bg-emerald-500/5 rounded-r-3xl blur-2xl pointer-events-none" />

                  <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                    <div>
                      <div className="flex items-center gap-2.5 mb-2.5">
                        <span className="text-2xl">{category.icon}</span>
                        <span className="text-xs font-black tracking-widest text-[#C5A880] uppercase font-heading bg-[#C5A880]/15 px-3 py-1 rounded-full border border-[#C5A880]/30">
                          ZONE 0{catIndex + 1} • {category.categoryName}
                        </span>
                        {spotlightMeta && (
                          <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${spotlightMeta.tagColor}`}>
                            {spotlightMeta.vibeBadge}
                          </span>
                        )}
                      </div>

                      <h3 className="font-heading text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#F5F5F0] leading-tight mb-2">
                        {category.title}
                      </h3>

                      <p className="text-xs sm:text-sm text-[#C5A880] font-semibold mb-2">
                        {category.tagline}
                      </p>

                      <p className="text-xs sm:text-sm text-[#9EB0A4] max-w-2xl leading-relaxed">
                        {category.description}
                      </p>
                    </div>

                    <div className="flex flex-wrap lg:flex-col gap-2 shrink-0">
                      {category.groups.map((grp) => (
                        <span
                          key={grp}
                          className="text-[11px] font-semibold text-[#DFDAD0] bg-black/40 border border-white/10 px-3 py-1 rounded-full"
                        >
                          • {grp}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 2. Non-Standard Horizontal Feature Spotlight Hero Card (Awwwards Style) */}
                {spotlightProduct && !searchQuery && (
                  <div className="mb-12 rounded-3xl bg-gradient-to-br from-[#162E20] via-[#10241A] to-[#0A1811] border border-[#C5A880]/30 p-6 sm:p-8 lg:p-10 shadow-2xl relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
                    
                    {/* Top Aesthetic Tag */}
                    <div className="flex items-center justify-between gap-3 pb-4 mb-6 border-b border-white/10">
                      <div className="flex items-center gap-2">
                        <Award className="w-4 h-4 text-[#C5A880]" />
                        <span className="text-xs font-mono font-bold tracking-wider text-[#DFCAAB] uppercase">
                          CURATOR SPOTLIGHT &amp; HIGHLIGHT ITEM
                        </span>
                      </div>
                      <span className="text-[11px] font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                        Vor Ort in Graz ausgestellt
                      </span>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                      {/* Left: Product Image / Cutout with Glowing Shadow */}
                      <div className="lg:col-span-5 flex justify-center">
                        <div className="relative w-full max-w-sm aspect-square rounded-2xl bg-gradient-to-b from-black/60 to-black/90 border border-white/10 p-6 flex items-center justify-center shadow-[0_10px_35px_rgba(16,185,129,0.2)] group-hover:shadow-[0_10px_45px_rgba(197,168,128,0.3)] transition-all">
                          {spotlightProduct.imageUrl ? (
                            <img
                              src={spotlightProduct.imageUrl}
                              alt={spotlightProduct.name}
                              referrerPolicy="no-referrer"
                              className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-500 drop-shadow-[0_8px_20px_rgba(0,0,0,0.6)]"
                            />
                          ) : (
                            <div className="text-center p-4">
                              <span className="text-6xl mb-3 block drop-shadow-[0_0_20px_rgba(197,168,128,0.5)]">
                                {category.icon}
                              </span>
                              <span className="text-xs font-heading font-bold text-[#C5A880] uppercase tracking-wider block">
                                {spotlightProduct.badge}
                              </span>
                            </div>
                          )}

                          <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-md px-2.5 py-1 rounded-full text-[10px] font-mono text-[#C5A880] border border-[#C5A880]/30">
                            ★ STAFF PICK
                          </div>
                        </div>
                      </div>

                      {/* Right: Detailed Story & Actions */}
                      <div className="lg:col-span-7 flex flex-col text-left">
                        <div className="flex flex-wrap items-center gap-2 mb-3">
                          <span className="text-xs font-bold text-[#DFCAAB] bg-[#C5A880]/20 px-3 py-1 rounded-full border border-[#C5A880]/40 font-heading">
                            {spotlightProduct.group}
                          </span>
                          <span className="text-xs font-bold text-emerald-300 bg-emerald-950/70 px-3 py-1 rounded-full border border-emerald-500/30">
                            {spotlightProduct.badge}
                          </span>
                        </div>

                        <h4 className="font-heading font-extrabold text-2xl sm:text-3xl lg:text-4xl text-[#F6F4EE] leading-tight mb-2">
                          {spotlightProduct.name}
                        </h4>

                        <p className="text-sm sm:text-base text-[#DFCAAB] font-medium mb-3">
                          {spotlightProduct.subtitle}
                        </p>

                        <p className="text-xs sm:text-sm text-[#DFDAD0] leading-relaxed mb-4">
                          {spotlightProduct.details}
                        </p>

                        {spotlightMeta && (
                          <blockquote className="p-3.5 rounded-xl bg-black/40 border-l-2 border-[#C5A880] text-xs text-[#9EB0A4] italic mb-6">
                            {spotlightMeta.curatorQuote}
                          </blockquote>
                        )}

                        {/* Dual Action Buttons */}
                        <div className="flex flex-wrap items-center gap-3">
                          <button
                            type="button"
                            onClick={() => setActiveAvailabilityProduct(spotlightProduct)}
                            className="btn-gold px-6 py-3 rounded-full text-xs font-bold inline-flex items-center gap-2 cursor-pointer shadow-lg shadow-[#C5A880]/20"
                          >
                            <Store className="w-4 h-4" />
                            <span>Verfügbarkeit im Store prüfen</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setActiveDetailProduct(spotlightProduct)}
                            className="px-5 py-3 rounded-full text-xs font-bold text-[#DFDAD0] hover:text-[#F5F5F0] bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#C5A880] transition-colors cursor-pointer"
                          >
                            <span>Details ansehen</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* 3. Sub-groups and Bento Grid Cards */}
                <div className="space-y-14">
                  {category.groups.map((groupName) => {
                    const groupItems = categoryProducts.filter((p) => p.group === groupName);
                    if (groupItems.length === 0) return null;

                    return (
                      <div key={groupName}>
                        {/* Sub-group Heading */}
                        <div className="flex items-center justify-between gap-3 mb-6 pb-2.5 border-b border-emerald-900/40">
                          <div className="flex items-center gap-3">
                            <span className="w-1.5 h-4 bg-[#C5A880] rounded-full" />
                            <h4 className="font-heading text-lg sm:text-xl font-bold text-[#F5F5F0] tracking-wide">
                              {groupName}
                            </h4>
                          </div>
                          <span className="text-xs font-mono text-[#8E9F94] font-medium">
                            {groupItems.length} {groupItems.length === 1 ? 'Artikel' : 'Artikel'}
                          </span>
                        </div>

                        {/* Product Cards Grid with Generous Spacing */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                          {groupItems.map((prod) => (
                            <ShowcaseProductCard
                              key={prod.id}
                              product={prod}
                              onOpenDetails={setActiveDetailProduct}
                              onCheckAvailability={setActiveAvailabilityProduct}
                            />
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Store Connection Banner */}
        <div className="mt-28 p-8 sm:p-10 rounded-3xl bg-gradient-to-br from-[#12281D] via-[#0E1F16] to-[#0A1811] border border-emerald-800/40 text-center relative overflow-hidden shadow-2xl">
          <div className="max-w-2xl mx-auto relative z-10">
            <span className="text-xs font-black tracking-widest text-[#C5A880] uppercase bg-[#C5A880]/15 border border-[#C5A880]/30 px-3 py-1 rounded-full inline-block mb-3 font-heading">
              PERSÖNLICHE BERATUNG IN GRAZ
            </span>
            <h3 className="font-heading text-2xl sm:text-3xl font-extrabold text-[#F5F5F0] mb-3">
              Möchten Sie einen Artikel vor Ort besichtigen?
            </h3>
            <p className="text-xs sm:text-sm text-[#9EB0A4] leading-relaxed mb-6">
              Unsere Fachberater an den Standorten Hauptbahnhof (Annenstraße 68) und Jakominiplatz (Radetzkystraße 13) beantworten gerne alle Fragen zu Inhaltsstoffen, Vaporizer-Technik und Zubehör.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <a
                href="#stores"
                className="btn-gold px-6 py-3 rounded-full text-xs font-bold inline-flex items-center gap-2 cursor-pointer shadow-lg shadow-[#C5A880]/20"
              >
                <span>Filialen &amp; Öffnungszeiten aufrufen</span>
                <ArrowRight className="w-4 h-4" />
              </a>
              <a
                href="tel:+43316584022"
                className="px-5 py-3 rounded-full text-xs font-bold text-[#DFDAD0] hover:text-[#F5F5F0] bg-white/5 border border-white/10 hover:border-[#C5A880] transition-colors"
              >
                Filiale Annenstraße anrufen
              </a>
            </div>
          </div>
        </div>

      </div>

      {/* 1. In-Store Detailed Specifications Modal */}
      <ProductDetailModal
        product={activeDetailProduct}
        onClose={() => setActiveDetailProduct(null)}
      />

      {/* 2. Interactive Store Availability & Direction Pop-up Modal */}
      <AvailabilityModal
        product={activeAvailabilityProduct}
        isOpen={Boolean(activeAvailabilityProduct)}
        onClose={() => setActiveAvailabilityProduct(null)}
        activeStore={activeStore}
        onSelectStore={onSelectStore}
      />
    </section>
  );
};
