import React, { useState } from 'react';
import { StoreId, AppView } from '../types';
import { MapPin, Menu, X, ArrowLeft, Package, Sparkles } from 'lucide-react';
import { GreenMonkeyLogo } from './GreenMonkeyLogo';

interface HeaderProps {
  activeStore: StoreId;
  onSelectStore: (id: StoreId) => void;
  currentView: AppView;
  onNavigate: (view: AppView) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeStore,
  onSelectStore,
  currentView,
  onNavigate,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleStoreClick = (id: StoreId) => {
    onSelectStore(id);
    if (currentView !== 'home') {
      onNavigate('home');
    }
    setTimeout(() => {
      const storeSection = document.getElementById('stores');
      if (storeSection) {
        storeSection.scrollIntoView({ behavior: 'smooth' });
      }
    }, 50);
  };

  const handleSectionClick = (sectionId: string) => {
    setMobileMenuOpen(false);
    if (currentView !== 'home') {
      onNavigate('home');
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    } else {
      const el = document.getElementById(sectionId);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header 
      className="sticky top-0 z-40 bg-[#162918] backdrop-blur-md border-b border-white/10 shadow-md shadow-black/30 transition-all duration-200"
      style={{ backgroundColor: '#162918' }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        
        {/* Brand Logo */}
        <button
          type="button"
          onClick={() => {
            onNavigate('home');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex items-center gap-3 group text-left cursor-pointer"
        >
          <div className="group-hover:scale-105 transition-transform">
            <GreenMonkeyLogo size="md" showRing={true} />
          </div>
          <div className="flex flex-col">
            <span className="font-heading font-bold text-base sm:text-lg tracking-wider text-[#F6F4EE] leading-tight group-hover:text-[#C5A880] transition-colors">
              GREEN MONKEY
            </span>
            <span className="text-[10px] tracking-widest text-[#C5A880] font-semibold">
              CANNABIS SHOP • GRAZ
            </span>
          </div>
        </button>

        {/* Location Quick Switcher (Dual Location Selector) */}
        <div className="hidden md:flex items-center gap-1.5 bg-[#0B1A12]/95 px-2.5 py-1 rounded-full border border-white/15 shadow-md">
          <span className="text-[11px] font-mono font-bold text-[#8E9F94] px-1 uppercase tracking-wider">
            FILIALE:
          </span>
          <button
            type="button"
            onClick={() => handleStoreClick('annen')}
            className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full transition-all cursor-pointer ${
              activeStore === 'annen'
                ? 'bg-[#C5A880]/25 text-[#DFCAAB] border border-[#C5A880]/60 shadow-sm'
                : 'text-[#8E9F94] hover:text-[#DFDAD0]'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                activeStore === 'annen'
                  ? 'bg-emerald-400 shadow-[0_0_8px_#34D399]'
                  : 'bg-neutral-600'
              }`}
            />
            <span>Store 1: Hauptbahnhof (Annenstr. 68)</span>
          </button>
          <button
            type="button"
            onClick={() => handleStoreClick('jako')}
            className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full transition-all cursor-pointer ${
              activeStore === 'jako'
                ? 'bg-[#C5A880]/25 text-[#DFCAAB] border border-[#C5A880]/60 shadow-sm'
                : 'text-[#8E9F94] hover:text-[#DFDAD0]'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                activeStore === 'jako'
                  ? 'bg-emerald-400 shadow-[0_0_8px_#34D399]'
                  : 'bg-neutral-600'
              }`}
            />
            <span>Store 2: Jakominiplatz (City Center)</span>
          </button>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-5">
          <button
            type="button"
            onClick={() => {
              onNavigate('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`text-xs tracking-wider uppercase font-medium transition-colors cursor-pointer py-1 ${
              currentView === 'home'
                ? 'text-[#C5A880] font-bold border-b-2 border-[#C5A880]'
                : 'text-[#DFDAD0] hover:text-[#DFCAAB]'
            }`}
          >
            Startseite
          </button>

          {/* Catalog Tab Button - Clear & Prominent */}
          <button
            type="button"
            onClick={() => {
              onNavigate('catalog');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`inline-flex items-center gap-1.5 text-xs tracking-wider uppercase px-3 py-1.5 rounded-full transition-all cursor-pointer ${
              currentView === 'catalog'
                ? 'bg-[#C5A880] text-[#09140E] font-extrabold shadow-md shadow-[#C5A880]/20'
                : 'bg-white/5 text-[#DFCAAB] hover:bg-[#C5A880]/20 border border-[#C5A880]/40'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Katalog</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/30 font-mono">50+</span>
          </button>

          <button
            type="button"
            onClick={() => handleSectionClick('departments')}
            className="text-xs tracking-wider uppercase font-medium text-[#DFDAD0] hover:text-[#DFCAAB] transition-colors cursor-pointer"
          >
            Sortimente
          </button>

          <button
            type="button"
            onClick={() => handleSectionClick('brands')}
            className="text-xs tracking-wider uppercase font-medium text-[#DFDAD0] hover:text-[#DFCAAB] transition-colors cursor-pointer"
          >
            Marken
          </button>

          <button
            type="button"
            onClick={() => handleSectionClick('stores')}
            className="text-xs tracking-wider uppercase font-medium text-[#DFDAD0] hover:text-[#DFCAAB] transition-colors cursor-pointer"
          >
            Filialen
          </button>

          <button
            type="button"
            onClick={() => handleSectionClick('guide')}
            className="text-xs tracking-wider uppercase font-medium text-[#DFDAD0] hover:text-[#DFCAAB] transition-colors cursor-pointer"
          >
            Rechtliches
          </button>

          <button
            type="button"
            onClick={() => handleSectionClick('faq')}
            className="text-xs tracking-wider uppercase font-medium text-[#DFDAD0] hover:text-[#DFCAAB] transition-colors cursor-pointer"
          >
            FAQ
          </button>
        </nav>

        {/* Header Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {currentView === 'catalog' ? (
            <button
              type="button"
              onClick={() => {
                onNavigate('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-1.5 text-xs font-semibold px-4 py-2 rounded-full bg-white/10 hover:bg-white/15 text-[#F6F4EE] border border-white/10 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Startseite</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                onNavigate('catalog');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hidden sm:inline-flex items-center gap-1.5 text-xs font-bold px-4 py-2 rounded-full btn-gold cursor-pointer"
            >
              <Package className="w-3.5 h-3.5" />
              <span>Katalog öffnen</span>
            </button>
          )}

          {/* Mobile Menu Toggle */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-[#DFDAD0] hover:text-[#F6F4EE] hover:bg-white/5 transition-colors cursor-pointer"
            aria-label="Menü öffnen"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0F2218] border-b border-[#C5A880]/20 px-5 py-4 flex flex-col gap-3 shadow-2xl animate-in slide-in-from-top-2">
          {/* Mobile store switcher */}
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <span className="text-xs font-semibold text-[#8E9F94]">STORE WÄHLEN:</span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  handleStoreClick('annen');
                  setMobileMenuOpen(false);
                }}
                className={`text-xs px-2.5 py-1 rounded-full font-semibold ${
                  activeStore === 'annen'
                    ? 'bg-[#C5A880] text-[#07150D]'
                    : 'bg-white/5 text-[#DFDAD0]'
                }`}
              >
                Store 1: Hauptbahnhof
              </button>
              <button
                type="button"
                onClick={() => {
                  handleStoreClick('jako');
                  setMobileMenuOpen(false);
                }}
                className={`text-xs px-2.5 py-1 rounded-full font-semibold ${
                  activeStore === 'jako'
                    ? 'bg-[#C5A880] text-[#07150D]'
                    : 'bg-white/5 text-[#DFDAD0]'
                }`}
              >
                Store 2: Jakominiplatz
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-1.5 pt-1">
            <button
              type="button"
              onClick={() => {
                onNavigate('home');
                setMobileMenuOpen(false);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`text-left py-2 text-sm font-semibold border-b border-white/5 ${
                currentView === 'home' ? 'text-[#C5A880]' : 'text-[#DFDAD0]'
              }`}
            >
              Startseite
            </button>

            <button
              type="button"
              onClick={() => {
                onNavigate('catalog');
                setMobileMenuOpen(false);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`text-left py-2 text-sm font-semibold border-b border-white/5 flex items-center justify-between ${
                currentView === 'catalog' ? 'text-[#C5A880]' : 'text-[#DFCAAB]'
              }`}
            >
              <span className="flex items-center gap-2">
                <Package className="w-4 h-4" />
                Vollständiger Katalog
              </span>
              <span className="text-[10px] bg-[#C5A880]/20 text-[#DFCAAB] px-2 py-0.5 rounded-full font-bold">50+ Artikel</span>
            </button>

            <button
              type="button"
              onClick={() => handleSectionClick('departments')}
              className="text-left py-2 text-sm font-medium text-[#DFDAD0] hover:text-[#DFCAAB] border-b border-white/5"
            >
              Sortiments-Bereiche
            </button>

            <button
              type="button"
              onClick={() => handleSectionClick('brands')}
              className="text-left py-2 text-sm font-medium text-[#DFDAD0] hover:text-[#DFCAAB] border-b border-white/5"
            >
              Marken-Übersicht
            </button>

            <button
              type="button"
              onClick={() => handleSectionClick('stores')}
              className="text-left py-2 text-sm font-medium text-[#DFDAD0] hover:text-[#DFCAAB] border-b border-white/5"
            >
              Filialen &amp; Öffnungszeiten
            </button>

            <button
              type="button"
              onClick={() => handleSectionClick('guide')}
              className="text-left py-2 text-sm font-medium text-[#DFDAD0] hover:text-[#DFCAAB] border-b border-white/5"
            >
              Rechtliches &amp; CBD-Guide
            </button>

            <button
              type="button"
              onClick={() => handleSectionClick('faq')}
              className="text-left py-2 text-sm font-medium text-[#DFDAD0] hover:text-[#DFCAAB]"
            >
              Häufige Fragen (FAQ)
            </button>
          </div>

          <div className="pt-2">
            <button
              type="button"
              onClick={() => {
                onNavigate('catalog');
                setMobileMenuOpen(false);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="w-full py-2.5 rounded-full text-xs font-bold btn-gold text-center block"
            >
              Katalog öffnen (Alle Artikel)
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
