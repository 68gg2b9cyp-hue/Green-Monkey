import React, { useState, useEffect } from 'react';
import { ShieldAlert, ExternalLink, ArrowRight } from 'lucide-react';

interface AgeGateModalProps {
  isOpen?: boolean;
  onVerified?: () => void;
  onClose?: () => void;
}

export const AgeGateModal: React.FC<AgeGateModalProps> = ({ 
  isOpen: controlledIsOpen, 
  onVerified, 
  onClose 
}) => {
  const [internalIsOpen, setInternalIsOpen] = useState(false);
  const [hasDeniedAccess, setHasDeniedAccess] = useState(false);

  useEffect(() => {
    // Check local storage for previous verification
    const verified = localStorage.getItem('gm_age_verified');
    if (verified !== 'true') {
      setInternalIsOpen(true);
    }
  }, []);

  const isOpen = controlledIsOpen !== undefined ? controlledIsOpen : internalIsOpen;

  const handleConfirm = () => {
    localStorage.setItem('gm_age_verified', 'true');
    setInternalIsOpen(false);
    setHasDeniedAccess(false);
    if (onVerified) onVerified();
    if (onClose) onClose();
  };

  const handleReject = () => {
    localStorage.removeItem('gm_age_verified');
    setHasDeniedAccess(true);
    try {
      window.location.href = 'https://www.google.at';
    } catch {
      // Fallback
    }
  };

  if (!isOpen) return null;

  return (
    <div
      id="age-gate-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md transition-opacity duration-300"
      role="dialog"
      aria-modal="true"
      aria-labelledby="age-gate-title"
    >
      <div 
        id="age-gate-card" 
        className="w-full max-w-lg bg-[#0F2218]/95 border border-[#C5A880]/30 rounded-3xl p-6 sm:p-8 text-center shadow-2xl relative overflow-hidden text-white"
      >
        {/* Brand pill */}
        <div className="inline-flex items-center gap-2 text-xs text-[#DFCAAB] bg-[#C5A880]/15 border border-[#C5A880]/30 px-3.5 py-1 rounded-full mb-5 tracking-wider font-semibold font-mono">
          <span>GREEN MONKEY GRAZ</span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880] pulse-dot-gold" />
          <span>JUGENDSCHUTZ • 18+ VERIFICATION</span>
        </div>

        {/* 18+ Badge with Seal Glow */}
        <div className="mx-auto w-20 h-20 rounded-2xl bg-gradient-to-br from-[#1a3826] via-[#10241A] to-[#0A160F] border-2 border-[#C5A880] flex flex-col items-center justify-center mb-4 shadow-xl shadow-black/60 relative">
          <span className="font-heading text-2xl font-black text-[#DFCAAB] tracking-tight leading-none">
            18+
          </span>
          <span className="text-[9px] font-mono tracking-widest text-[#C5A880] uppercase mt-0.5">
            LEGAL AGE
          </span>
          <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_#34D399]" />
        </div>

        {/* Bilingual Title */}
        <h2 
          id="age-gate-title" 
          className="text-xl sm:text-2xl font-black font-heading text-[#F6F4EE] mb-2 tracking-tight"
        >
          Altersüberprüfung / Age Verification 18+
        </h2>

        {!hasDeniedAccess ? (
          <>
            <p className="text-xs sm:text-sm text-[#DFCAAB] font-medium leading-relaxed mb-1 max-w-md mx-auto">
              Der Zutritt zu unserem Angebot ist erst ab 18 Jahren gestattet.
            </p>
            <p className="text-xs text-[#9EB0A4] italic mb-6 max-w-md mx-auto">
              Access to this website is restricted to individuals aged 18 and older.
            </p>

            <div className="text-xs text-[#8E9F94] mb-6 leading-relaxed bg-black/50 border border-white/10 rounded-2xl p-4 text-left space-y-2">
              <p>
                <strong>Hinweis (DE):</strong> Dieses Webangebot dient ausschließlich der Information über unser Sortiment vor Ort in unseren beiden Grazer Stores. Gemäß dem steirischen Jugendschutzgesetz sowie dem TNRSG.
              </p>
              <p className="text-[11px] text-[#8E9F94]/90 border-t border-white/5 pt-1.5">
                <strong>Notice (EN):</strong> Informational product showcase only. No online sales or shipping. Physical in-store purchase in Graz, Austria upon presentation of valid ID.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button
                id="btn-age-confirm"
                type="button"
                onClick={handleConfirm}
                className="w-full sm:w-auto flex-1 py-3.5 px-6 rounded-full text-xs font-bold uppercase tracking-wider btn-gold transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-[#C5A880]/20"
              >
                <span>Ja, ich bin 18+ / Yes, I am 18+</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                id="btn-age-reject"
                type="button"
                onClick={handleReject}
                className="w-full sm:w-auto py-3.5 px-6 rounded-full text-xs font-semibold text-[#DFDAD0] hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all cursor-pointer"
              >
                Nein / Under 18 (Exit)
              </button>
            </div>
          </>
        ) : (
          <div className="py-4">
            <div className="p-4 rounded-2xl bg-red-950/40 border border-red-500/30 text-left mb-6">
              <div className="flex items-center gap-2 text-red-300 font-semibold text-sm mb-1.5">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>Zutritt verweigert</span>
              </div>
              <p className="text-xs text-red-200/80 leading-relaxed">
                Der Zutritt zu unserem Produktkatalog und Informationsportal ist Personen unter 18 Jahren gesetzlich untersagt.
              </p>
            </div>
            <a
              href="https://www.google.at"
              className="inline-flex items-center gap-2 py-2.5 px-6 rounded-full text-xs font-semibold text-[#DFCAAB] bg-black/50 border border-white/10 hover:border-[#C5A880] transition-colors"
            >
              <span>Zur Google-Startseite wechseln</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        )}

        <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-center gap-1.5 text-xs text-[#8E9F94]">
          <span>Reine Informationsseite • Kein Online-Shop • Nur vor Ort in Graz</span>
        </div>
      </div>
    </div>
  );
};
