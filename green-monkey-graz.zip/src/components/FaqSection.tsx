import React, { useState } from 'react';
import { FAQ_ITEMS } from '../data/storeData';
import { Plus, Minus } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openId, setOpenId] = useState<string | null>(FAQ_ITEMS[0].id);

  const toggle = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  return (
    <section className="py-16 md:py-24 border-t border-white/10" id="faq">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="inline-block text-xs font-bold tracking-widest text-[#C5A880] uppercase mb-2 font-heading">
            HÄUFIG GESTELLTE FRAGEN
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl font-bold text-[#F6F4EE] mb-3">
            Fragen &amp; Antworten zum Sortiment
          </h2>
          <p className="text-sm sm:text-base text-[#DFDAD0] leading-relaxed">
            Wissenswertes zu österreichischen Richtlinien (§1 SMG), Store-Verfügbarkeiten und Alterskontrolle.
          </p>
        </div>

        {/* Accordion List */}
        <div className="flex flex-col gap-3.5">
          {FAQ_ITEMS.map((item) => {
            const isOpen = openId === item.id;
            return (
              <div
                key={item.id}
                className={`border rounded-2xl overflow-hidden transition-all duration-200 ${
                  isOpen ? 'border-[#C5A880]/60 bg-[#12281D] shadow-xl' : 'border-white/10 bg-[#0F2218]/90 hover:border-white/20'
                }`}
              >
                <button
                  type="button"
                  onClick={() => toggle(item.id)}
                  className="w-full text-left p-5 flex items-center justify-between gap-4 cursor-pointer"
                  aria-expanded={isOpen}
                >
                  <span className="font-heading text-sm sm:text-base font-bold text-[#F6F4EE]">
                    {item.question}
                  </span>
                  <span
                    className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 border transition-all ${
                      isOpen
                        ? 'bg-[#C5A880] text-[#07150D] border-[#C5A880] rotate-180'
                        : 'bg-black/30 text-[#DFCAAB] border-white/10'
                    }`}
                  >
                    {isOpen ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  </span>
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-[#DFDAD0] leading-relaxed border-t border-white/5 pt-3">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
