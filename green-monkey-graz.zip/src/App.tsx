import React, { useState } from 'react';
import { ProductCategory, StoreId, AppView } from './types';
import { AgeGateModal } from './components/AgeGateModal';
import { LegalModal, LegalModalTab } from './components/LegalModal';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { HomeStoreStatusBar } from './components/HomeStoreStatusBar';
import { DepartmentOverview } from './components/DepartmentOverview';
import { LuxuryProductShowcase } from './components/LuxuryProductShowcase';
import { RawHighlightSection } from './components/RawHighlightSection';
import { DualShowcase } from './components/DualShowcase';
import { BrandBar } from './components/BrandBar';
import { StoresSection } from './components/StoresSection';
import { QualityPillarsSection } from './components/QualityPillarsSection';
import { GuideSection } from './components/GuideSection';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { CatalogSection } from './components/CatalogSection';
import { CornerLogoBadge } from './components/CornerLogoBadge';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [activeStore, setActiveStore] = useState<StoreId>('annen');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('all');
  const [selectedBrand, setSelectedBrand] = useState<string | null>(null);

  // Legal Modal & Age Gate State
  const [isLegalModalOpen, setIsLegalModalOpen] = useState(false);
  const [legalModalTab, setLegalModalTab] = useState<LegalModalTab>('impressum');
  const [isAgeGateForceOpen, setIsAgeGateForceOpen] = useState(false);

  const handleNavigate = (view: AppView) => {
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenCatalog = (category: ProductCategory = 'all', brand: string | null = null) => {
    setSelectedCategory(category);
    setSelectedBrand(brand);
    setCurrentView('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBrandSelect = (brand: string | null) => {
    setSelectedBrand(brand);
    if (brand) {
      setCurrentView('catalog');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleCategorySelect = (category: ProductCategory) => {
    setSelectedCategory(category);
    setCurrentView('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenLegal = (tab: LegalModalTab) => {
    setLegalModalTab(tab);
    setIsLegalModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#0A160F] text-[#F6F4EE] flex flex-col selection:bg-[#C5A880] selection:text-[#07150D]">
      {/* 18+ Age Gate Protection */}
      <AgeGateModal
        isOpen={isAgeGateForceOpen ? true : undefined}
        onClose={() => setIsAgeGateForceOpen(false)}
      />

      {/* Austrian Compliance & Legal Information Modal (Impressum, Datenschutz, Cookies) */}
      <LegalModal
        isOpen={isLegalModalOpen}
        initialTab={legalModalTab}
        onClose={() => setIsLegalModalOpen(false)}
      />

      {/* Main Top Navigation Header */}
      <Header
        activeStore={activeStore}
        onSelectStore={setActiveStore}
        currentView={currentView}
        onNavigate={handleNavigate}
      />

      {/* Main Page Content */}
      <main className="flex-grow">
        {currentView === 'catalog' ? (
          /* Dedicated Interactive Catalog View */
          <CatalogSection
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            selectedBrand={selectedBrand}
            onSelectBrand={setSelectedBrand}
            onBackToHome={() => handleNavigate('home')}
          />
        ) : (
          /* Home View */
          <>
            {/* Hero Section */}
            <HeroSection
              onOpenCatalog={() => handleOpenCatalog('all')}
              onScrollToStores={() => {
                const el = document.getElementById('stores');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
            />

            {/* Quick Live Store Status Bar */}
            <HomeStoreStatusBar
              activeStore={activeStore}
              onSelectStore={setActiveStore}
            />

            {/* 4 Core Department Pillars */}
            <DepartmentOverview
              onSelectCategory={handleCategorySelect}
              onOpenFullCatalog={() => handleOpenCatalog('all')}
            />

            {/* Visual Luxury Showcase with Interactive Filter & Details */}
            <LuxuryProductShowcase 
              activeStore={activeStore}
              onSelectStore={setActiveStore}
            />

            {/* RAW Official Headshop Highlight Banner */}
            <RawHighlightSection
              onSelectBrand={handleBrandSelect}
              onSelectCategory={handleCategorySelect}
            />

            {/* Dual Focus: Wellness & Headshop */}
            <DualShowcase onSelectCategory={handleCategorySelect} />

            {/* Authorized Brands Bar */}
            <BrandBar
              activeBrand={selectedBrand}
              onSelectBrand={handleBrandSelect}
              onSelectCategory={handleCategorySelect}
            />

            {/* Physical Stores in Graz (HBF & Jakominiplatz) */}
            <StoresSection
              activeStore={activeStore}
              onSelectStore={setActiveStore}
            />

            {/* Trust & Quality Pillars */}
            <QualityPillarsSection
              onOpenCatalog={() => handleOpenCatalog('all')}
            />

            {/* Austrian CBD & Compliance Guide */}
            <GuideSection />

            {/* FAQ Section */}
            <FaqSection />
          </>
        )}
      </main>

      {/* Full Austrian Compliance Footer */}
      <Footer
        onNavigate={handleNavigate}
        onSelectCategory={handleCategorySelect}
        onOpenLegal={handleOpenLegal}
        onOpenAgeGate={() => setIsAgeGateForceOpen(true)}
      />

      {/* Persistent Corner Logo Badge */}
      <CornerLogoBadge />
    </div>
  );
}
